from fastapi import FastAPI
from app.database import Base, engine
from app.models import employee  # This is needed to register the Employee table

from app.routes import employee as employee_routes
from app.routes import department as department_routes
from app.routes import job_role as job_role_routes
from app.routes import performance_review as performance_review_routes
from app.routes import notification as notification_routes
from app.routes import ai_retention_risk as ai_retention_risk_routes
from app.routes import expense

app = FastAPI()

# # Create the tables in the DB (if they don't exist)
# Base.metadata.create_all(bind=engine)

# Root endpoint
@app.get("/")
def welcome():
    return {"message": "Welcome to Alpixn HR API"}

# Include the employee API routes
app.include_router(employee_routes.router)
app.include_router(department_routes.router)
app.include_router(job_role_routes.router)
app.include_router(performance_review_routes.router)
app.include_router(notification_routes.router)
app.include_router(ai_retention_risk_routes.router)
app.include_router(expense.router)

from app.routes import ai_mood_index

app.include_router(ai_mood_index.router)
from app.routes import letter
app.include_router(letter.router)

from app.routes import career_path_routes
app.include_router(career_path_routes.router)