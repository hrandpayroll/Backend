# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

# import os
# for dirname, _, filenames in os.walk('/kaggle/input'):
#     for filename in filenames:
#         print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session


# # Intuition behind the adding weights to Ensemble Model as opposed to simple averaging:
# 
# ## 1. Model Weighting
# Our Approach treats TextBlob, VADER, and BERT scores equally, but our comparison suggests VADER and BERT may outperform TextBlob in certain cases. A weighted average or ensemble approach could improve accuracy.
# 
# ### Suggested weights (adjust as needed):
# 1. Notifications: VADER (0.5), BERT (0.3), TextBlob (0.2) — VADER is best for short, informal texts.
# 2. Performance Reviews: BERT (0.5), VADER (0.3), TextBlob (0.2) — BERT handles mixed tones well.
# 3. Letters: TextBlob (0.4), BERT (0.3), VADER (0.3) — TextBlob is conservative for formal texts.
# 
# ### Define Source Weights:
# Assign weights to each text source:
# 1. Performance Reviews: 0.5 (highest, as they’re comprehensive).
# 2. Letters: 0.3 (formal but less frequent).
# 3. Notifications: 0.2 (lowest, often short and informal).
# These weights sum to 1.0 for the final mood score.
# 
# ## 2. Temporal Weighting
# 
# Issue: Our notebook aggregates all texts without considering their recency. Recent notifications or performance reviews may reflect an employee’s current mood better than older ones, but they’re weighted equally in the current implementation.
# 
# Goal: Incorporate temporal weighting to prioritize recent texts, ensuring the AI mood index reflects more current sentiments. This will make the mood scores more relevant for HR decision-making, as recent feedback (e.g., a recent “formal notice”) is likely more indicative of an employee’s present state.
# What to Do:
# 
# Define a Temporal Weighting Scheme:
# 
# Use an exponential decay function to assign higher weights to recent texts:
# $$\text{Text\_Weight} = e^{-\lambda \cdot \text{age\_in\_days}}$$
# Where:
# 
# $ \lambda $: Decay rate (e.g., 0.01 for slow decay, meaning older texts still contribute but less).
# $ \text{age\_in\_days} $: Days since the text was created.
# 
# 
# Assume each text has a timestamp (e.g., created_at for notifications, review_date for performance reviews, sent_date for letters). Since your mock data (mock_notifications.csv, mock_letters.csv, mock_performance_reviews.csv) doesn’t include timestamps, we’ll simulate them for testing.

# ## 3.Text Preprocessing Plan
# 
# Issue: Raw HR texts (e.g., "Approved.", "System maintenance will occur this weekend.") contain noise like stop words, punctuation, or inconsistent casing, which can skew sentiment analysis. Short texts (e.g., "Hi.", "Noted.") often get misclassified by models like TextBlob or VADER, leading to inaccurate scores (e.g., Employee 105’s BERT score of 0.99 seems high for "Approved.").
# 
# Goal: Clean texts to improve sentiment accuracy by removing noise and handling short texts effectively.

# # Preprocessing Dependencies

# Import NLTK stopwords and download required resources for text preprocessing

import nltk
from nltk.corpus import stopwords
import string
import re

# Download NLTK stopwords
nltk.download('stopwords')
stop_words = set(stopwords.words('english'))


# # User Defined Functions

# ## Text Preprocessing Function

# Define function to clean text by removing stopwords, punctuation, and handling short texts

def preprocess_text(text):
    if not isinstance(text, str) or pd.isna(text):
        return None
    # Convert to lowercase
    text = text.lower()
    # Remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    # Remove stop words
    words = text.split()
    words = [word for word in words if word not in stop_words]
    cleaned_text = ' '.join(words)
    # Return None for short texts (<10 characters after cleaning)
    if len(cleaned_text) < 10:
        return None
    return cleaned_text


# ## Compute Mood Score

# Update compute_mood_score to apply preprocessing before sentiment analysis

def compute_mood_score(text, text_type):
    cleaned_text = preprocess_text(text)
    if cleaned_text is None:
        # Assign neutral score for short or invalid texts
        return 0.5, 0.5, 0.5, 0.5

    tb_score = mood_textblob(cleaned_text)
    vd_score = mood_vader(cleaned_text)
    bt_score = mood_bert(cleaned_text)

    # Model weights based on text type
    if text_type == 'notification':
        w_tb, w_vd, w_bt = 0.2, 0.5, 0.3
    elif text_type == 'performance_review':
        w_tb, w_vd, w_bt = 0.2, 0.3, 0.5
    else:  # letter
        w_tb, w_vd, w_bt = 0.4, 0.3, 0.3

    # Weighted model score
    model_score = w_tb * tb_score + w_vd * vd_score + w_bt * bt_score
    return round(model_score, 2), tb_score, vd_score, bt_score


# ## temporal weight function

# Updated temporal weight function
def get_temporal_weight(timestamp, reference_time, decay_rate=0.01):
    if pd.isna(timestamp):
        return 1.0  # Neutral weight if timestamp missing
    age_days = (reference_time - pd.to_datetime(timestamp)).days
    return np.exp(-decay_rate * max(age_days, 0))


# # Initialize models

import pandas as pd
import numpy as np
from datetime import datetime
from textblob import TextBlob
from nltk.sentiment import SentimentIntensityAnalyzer
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
from transformers import BertTokenizerFast, BertForSequenceClassification

# Initialize models
sia = SentimentIntensityAnalyzer()
# bert_model_path = "/kaggle/input/pretraining-bert-to-hr-text/bert_hr_mood_model/"  # path to your uploaded model
# bert_tokenizer = BertTokenizerFast.from_pretrained(bert_model_path)
# bert_model = BertForSequenceClassification.from_pretrained(bert_model_path)
# bert_model.eval()
bert_model_name = "nlptown/bert-base-multilingual-uncased-sentiment"
bert_tokenizer = AutoTokenizer.from_pretrained(bert_model_name)
bert_model = AutoModelForSequenceClassification.from_pretrained(bert_model_name)
bert_sentiment = pipeline("sentiment-analysis", model=bert_model, tokenizer=bert_tokenizer)


# ## User-Defined Functions

# ### Mood Scores


def mood_textblob(text):
    return round((TextBlob(text).sentiment.polarity + 1) / 2, 2)

def mood_vader(text):
    return round((sia.polarity_scores(text)["compound"] + 1) / 2, 2)

def mood_bert(text):
    result = bert_sentiment(text[:512])[0]
    stars = int(result['label'].split()[0])
    return round((stars - 1) / 4, 2)
# import torch

# label_to_score = {0: 0.1, 1: 0.3, 2: 0.5, 3: 0.7, 4: 0.9}

# def mood_bert(text):
#     inputs = bert_tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=128)
#     with torch.no_grad():
#         outputs = bert_model(**inputs)
#         predicted_label = torch.argmax(outputs.logits, dim=1).item()
#     return label_to_score[predicted_label]


# ### Collect Texts


# Collect texts with source types
def collect_text(emp_id, notifications, performance_reviews, letters):
    texts = []
    text_types = []
    timestamps = []

    # Notifications
    for _, row in notifications[notifications.employee_id == emp_id].iterrows():
        texts.append(row['message'])
        text_types.append('notification')
        timestamps.append(row.get('Generated on'))

    # Performance Reviews
    for _, row in performance_reviews[performance_reviews.employee_id == emp_id].iterrows():
        if pd.notnull(row['strengths']):
            texts.append(row['strengths'])
            text_types.append('performance_review')
            timestamps.append(row.get('Generated on'))
        if pd.notnull(row['areas_of_improvement']):
            texts.append(row['areas_of_improvement'])
            text_types.append('performance_review')
            timestamps.append(row.get('Generated on'))

    # Letters
    for _, row in letters[letters.employee_id == emp_id].iterrows():
        texts.append(row['text'])
        text_types.append('letter')
        timestamps.append(row.get('Generated on'))

    return texts, text_types,timestamps


# ### Weighted Mood_Index


def generate_mood_index(notifications, performance_reviews, letters):
    employee_ids = sorted(set(notifications.employee_id) |
                          set(performance_reviews.employee_id) |
                          set(letters.employee_id))
    records = []

    # Source weights
    w_pr = 0.5  # Performance reviews
    w_letter = 0.3  # Letters
    w_notif = 0.2  # Notifications

    for emp_id in employee_ids:
        texts, text_types,timestamps = collect_text(emp_id, notifications, performance_reviews, letters)

        if not texts:  # Handle employees with no texts
            records.append({
                'employee_id': emp_id,
                'textblob_score': 0.5,
                'vader_score': 0.5,
                'bert_score': 0.5,
                'final_mood_score': 0.5,
                'recorded_on': datetime.now()
            })
            continue

        # Compute scores for each text
        pr_scores = []
        letter_scores = []
        notif_scores = []
        pr_tb_scores, pr_vd_scores, pr_bt_scores = [], [], []
        letter_tb_scores, letter_vd_scores, letter_bt_scores = [], [], []
        notif_tb_scores, notif_vd_scores, notif_bt_scores = [], [], []
        temporal_weights = []

        # Use most recent timestamp as reference
        valid_timestamps = [pd.to_datetime(t) for t in timestamps if pd.notna(t)]
        reference_time = max(valid_timestamps) if valid_timestamps else datetime.now()

        for text, text_type, timestamp in zip(texts, text_types, timestamps):
            temporal_weight = get_temporal_weight(timestamp, reference_time)
            model_score, tb_score, vd_score, bt_score = compute_mood_score(text, text_type)
            if text_type == 'performance_review':
                pr_scores.append(model_score * temporal_weight)
                pr_tb_scores.append(tb_score * temporal_weight)
                pr_vd_scores.append(vd_score * temporal_weight)
                pr_bt_scores.append(bt_score * temporal_weight)
            elif text_type == 'letter':
                letter_scores.append(model_score * temporal_weight)
                letter_tb_scores.append(tb_score * temporal_weight)
                letter_vd_scores.append(vd_score * temporal_weight)
                letter_bt_scores.append(bt_score * temporal_weight)
            else:  # notification
                notif_scores.append(model_score * temporal_weight)
                notif_tb_scores.append(tb_score * temporal_weight)
                notif_vd_scores.append(vd_score * temporal_weight)
                notif_bt_scores.append(bt_score * temporal_weight)
            temporal_weights.append(temporal_weight)

        # Average scores per source with temporal weights
        total_pr_weight = sum(temporal_weights[i] for i, t in enumerate(text_types) if t == 'performance_review') or 1
        total_letter_weight = sum(temporal_weights[i] for i, t in enumerate(text_types) if t == 'letter') or 1
        total_notif_weight = sum(temporal_weights[i] for i, t in enumerate(text_types) if t == 'notification') or 1

        pr_score = sum(pr_scores) / total_pr_weight if pr_scores else 0.5
        letter_score = sum(letter_scores) / total_letter_weight if letter_scores else 0.5
        notif_score = sum(notif_scores) / total_notif_weight if notif_scores else 0.5

        # Average model scores with temporal weights
        total_weight = sum(temporal_weights) or 1
        tb_score = sum(pr_tb_scores + letter_tb_scores + notif_tb_scores) / total_weight if (pr_tb_scores or letter_tb_scores or notif_tb_scores) else 0.5
        vd_score = sum(pr_vd_scores + letter_vd_scores + notif_vd_scores) / total_weight if (pr_vd_scores or letter_vd_scores or notif_vd_scores) else 0.5
        bt_score = sum(pr_bt_scores + letter_bt_scores + notif_bt_scores) / total_weight if (pr_bt_scores or letter_bt_scores or notif_bt_scores) else 0.5

        # Final mood score with source weights
        final_score = w_pr * pr_score + w_letter * letter_score + w_notif * notif_score

        def get_mood_label(score):
            if score <= 0.20:
                return "Very Low"
            elif score <= 0.40:
                return "Low"
            elif score <= 0.60:
                return "Neutral"
            elif score <= 0.80:
                return "High"
            else:
                return "Very High"



        mood_label = get_mood_label(final_score)


        records.append({
            'employee_id': emp_id,
            'textblob_score': round(tb_score, 2),
            'vader_score': round(vd_score, 2),
            'bert_score': round(bt_score, 2),
            'final_mood_score': round(final_score, 2),
            'final_mood_label': mood_label,
            'recorded_on': datetime.now()
        })

    return pd.DataFrame(records)


# ## Keyword Dictionary for Context-Aware Sentiment Boosting

# ## Expanded Keyword Dictionary for Context-Aware Sentiment Boosting
# Define expanded HR-specific keywords with context-aware adjustments

keyword_dict = {
    'positive': {
        'exceeds': 0.1,
        'excellent': 0.1,
        'outstanding': 0.1,
        'promotion': 0.1,
        'commendable': 0.1,
        'exceptional': 0.1,
        'bonus': 0.1,
        'achievement': 0.1,
        'proactive': 0.1,
        'leadership': 0.1
    },
    'negative': {
        'disciplinary': -0.15,
        'warning': -0.15,
        'termination': -0.15,
        'violation': -0.15,
        'below': -0.1,
        'unsatisfactory': -0.1,
        'concern': -0.1,
        'insufficient': -0.1,
        'failure': -0.1,
        'improvement': -0.1  # Adjusted to -0.05 in performance reviews
    }
}
negation_words = {'not', 'never', 'no'}

# ## Updated Text Preprocessing with Context-Aware Keywords
# Preserve negation words, track keywords with context, and return context flag

def preprocess_text(text, text_type):
    if not isinstance(text, str) or pd.isna(text):
        return None, 0.0, 'standard'

    # Set context flag
    context_flag = 'constructive' if text_type == 'performance_review' else 'standard'

    # Store original text for keyword detection
    original_text = text.lower()

    # Detect keywords and compute sentiment adjustment
    keyword_adjustment = 0.0
    words = original_text.split()
    for word, score in keyword_dict['positive'].items():
        if word in original_text:
            word_idx = [i for i, w in enumerate(words) if w == word]
            for idx in word_idx:
                # Check for negation within 3 words before
                negated = False
                for j in range(max(0, idx-3), idx):
                    if words[j] in negation_words:
                        negated = True
                        break
                if not negated:
                    keyword_adjustment += score

    for word, score in keyword_dict['negative'].items():
        if word in original_text:
            word_idx = [i for i, w in enumerate(words) if w == word]
            for idx in word_idx:
                # Check for negation within 3 words before
                negated = False
                for j in range(max(0, idx-3), idx):
                    if words[j] in negation_words:
                        negated = True
                        break
                if not negated:
                    # Milder penalty for 'improvement' in performance reviews
                    adjusted_score = -0.05 if word == 'improvement' and context_flag == 'constructive' else score
                    keyword_adjustment += adjusted_score

    # Convert to lowercase
    text = original_text
    # Remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    # Remove stop words, but preserve negation words
    words = text.split()
    words = [word for word in words if word not in stop_words or word in negation_words]
    cleaned_text = ' '.join(words)

    # Return None for short texts (<10 characters after cleaning)
    if len(cleaned_text) < 10:
        return None, keyword_adjustment, context_flag
    return cleaned_text, keyword_adjustment, context_flag


# ## Final Mood Score Calculation

# ## Updated Compute Mood Score with Context-Aware Adjustments
# Apply context-aware keyword adjustments to model scores

def compute_mood_score(text, text_type):
    cleaned_text, keyword_adjustment, context_flag = preprocess_text(text, text_type)
    if cleaned_text is None:
        # Assign neutral score for short or invalid texts
        return 0.5, 0.5, 0.5, 0.5

    tb_score = mood_textblob(cleaned_text)
    vd_score = mood_vader(cleaned_text)
    bt_score = mood_bert(cleaned_text)

    # Apply keyword adjustment and cap scores at [0, 1]
    tb_score = max(0.0, min(1.0, tb_score + keyword_adjustment))
    vd_score = max(0.0, min(1.0, vd_score + keyword_adjustment))
    bt_score = max(0.0, min(1.0, bt_score + keyword_adjustment))

    # Model weights based on text type
    if text_type == 'notification':
        w_tb, w_vd, w_bt = 0.2, 0.5, 0.3
    elif text_type == 'performance_review':
        w_tb, w_vd, w_bt = 0.2, 0.3, 0.5
    else:  # letter
        w_tb, w_vd, w_bt = 0.4, 0.3, 0.3

    # Weighted model score
    model_score = w_tb * tb_score + w_vd * vd_score + w_bt * bt_score
    return round(model_score, 2), tb_score, vd_score, bt_score


# # Testing

# # Test the updated mood index with context-aware keywords using mock data

# notifications = pd.read_csv("/kaggle/input/50-employees-synthetic-dataset/Synthetic_Notifications__50_Employees_.csv")
# performance_reviews = pd.read_csv("/kaggle/input/50-employees-synthetic-dataset/Synthetic_Performance_Reviews__50_Employees_.csv")
# letters = pd.read_csv("/kaggle/input/50-employees-synthetic-dataset/Synthetic_Letters__50_Employees_.csv")
# mood_index_df = generate_mood_index(notifications, performance_reviews, letters)
# (mood_index_df)

from sqlalchemy.orm import Session
from app.models.notification import Notification
from app.models.performance_review import PerformanceReview
from app.models.letter import Letter

def calculate_final_mood_score(employee_id: int, db: Session) -> float:
    """
    Queries DB for texts, converts to DataFrames,
    calls generate_mood_index, and returns final score.
    """

    # Pull from DB
    notif_qs = db.query(Notification).all()
    review_qs = db.query(PerformanceReview).all()
    letter_qs = db.query(Letter).all()

    # Convert to DataFrames
    notifications_df = pd.DataFrame([
        {
            "employee_id": n.employee_id,
            "message": n.message,
            "Generated on": n.created_at if hasattr(n, "created_at") else None
        } for n in notif_qs
    ])

    reviews_df = pd.DataFrame([
        {
            "employee_id": r.employee_id,
            "strengths": r.strengths,
            "areas_of_improvement": r.areas_of_improvement,
            "Generated on": r.review_period
        } for r in review_qs
    ])

    letters_df = pd.DataFrame([
        {
            "employee_id": l.employee_id,
            "text": l.subject,
            "Generated on": l.generated_on
        } for l in letter_qs
    ])

    # Run full model
    mood_index_df = generate_mood_index(notifications_df, reviews_df, letters_df)

    row = mood_index_df[mood_index_df["employee_id"] == employee_id]

    if not row.empty:
        return float(row.iloc[0]["final_mood_score"])
    else:
        return 0.5  # fallback neutral score


