import os
import requests
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

prompt_template = """
You are a senior HR career advisor in a large organization. Your task is to assess an employee's profile and recommend their most suitable next career move.

Employee Profile:
- Current Role: {current_role}
- Department: {department}
- Date of Joining: {doj}
- Performance Rating (1–5): {rating}
- Promotion Recommended by Manager: {promotion_recommendation}

Please consider:
- Years in current role
- Performance consistency
- Whether promotion is realistic based on tenure
- Skills needed for next role
- Whether lateral move, specialization, or promotion is best

Return the following in JSON format:

{{
  "recommended_role": "...",
  "predicted_growth_years": ...,
  "suggested_courses": "..., ..., ..."
}}
"""

def predict_career_path_row(current_role, department, doj, rating, promotion_recommendation):
    prompt = prompt_template.format(
        current_role=current_role,
        department=department,
        doj=doj.strftime("%Y-%m-%d"),
        rating=rating,
        promotion_recommendation="Yes" if promotion_recommendation else "No"
    )

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "model": "deepseek/deepseek-r1:free",
        "messages": [{"role": "user", "content": prompt}]
    }

    response = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=data)

    result = response.json()['choices'][0]['message']['content']

    # Parse the output (assumes it's JSON)
    import json
    import re
    try:
        # Remove code block formatting if present
        result_clean = re.sub(r"^```(?:json)?\s*|```$", "", result.strip(), flags=re.IGNORECASE | re.MULTILINE)
        return json.loads(result_clean)
    
    except Exception as e:
        raise ValueError(f"LLM response could not be parsed: {result}")
    
if __name__ == "__main__":
    from datetime import datetime

    result = predict_career_path_row(
        current_role="Software Engineer",
        department="Engineering",
        doj=datetime(2020, 5, 15),
        rating=4,
        promotion_recommendation=True
    )

    print("AI Career Path Prediction:")
    print(result)