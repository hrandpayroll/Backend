from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.ai_mood_index import AIMoodIndexResponse
from app.crud.ai_mood_index import create_ai_mood_index

router = APIRouter(
    prefix="/ai-mood-index",
    tags=["AI Mood Index"]
)

@router.post("/{employee_id}", response_model=AIMoodIndexResponse)
def generate_ai_mood_index(employee_id: int, db: Session = Depends(get_db)):
    try:
        result = create_ai_mood_index(db, employee_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

from app.schemas.ai_mood_index import AIMoodIndexUpdate
from app.crud.ai_mood_index import update_ai_mood_index, delete_ai_mood_index

@router.patch("/{mood_id}", response_model=AIMoodIndexResponse)
def patch_ai_mood_index(mood_id: int, updates: AIMoodIndexUpdate, db: Session = Depends(get_db)):
    result = update_ai_mood_index(db, mood_id, updates.dict(exclude_unset=True))
    if not result:
        raise HTTPException(status_code=404, detail="Mood index not found")
    return result

@router.delete("/{mood_id}", response_model=AIMoodIndexResponse)
def delete_ai_mood_index_route(mood_id: int, db: Session = Depends(get_db)):
    result = delete_ai_mood_index(db, mood_id)
    if not result:
        raise HTTPException(status_code=404, detail="Mood index not found")
    return result

from app.crud.ai_mood_index import recalculate_ai_mood_index

@router.put("/recalculate/{mood_id}", response_model=AIMoodIndexResponse)
def recalculate_mood(mood_id: int, db: Session = Depends(get_db)):
    result = recalculate_ai_mood_index(db, mood_id)
    if not result:
        raise HTTPException(status_code=404, detail="Mood index not found or no data to recalculate")
    return result

    