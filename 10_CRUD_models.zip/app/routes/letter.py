from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.letter import LetterCreate, LetterResponse
from app.crud.letter import create_letter, get_letters_by_employee

router = APIRouter(
    prefix="/letters",
    tags=["Letters"]
)

@router.post("/", response_model=LetterResponse)
def create(letter: LetterCreate, db: Session = Depends(get_db)):
    return create_letter(db, letter)

@router.get("/employee/{employee_id}", response_model=list[LetterResponse])
def get_by_employee(employee_id: int, db: Session = Depends(get_db)):
    return get_letters_by_employee(db, employee_id)

from app.schemas.letter import LetterUpdate
from app.crud.letter import update_letter

@router.patch("/{letter_id}", response_model=LetterResponse)
def patch_letter(letter_id: int, update: LetterUpdate, db: Session = Depends(get_db)):
    updated = update_letter(db, letter_id, update.dict(exclude_unset=True))
    if not updated:
        raise HTTPException(status_code=404, detail="Letter not found")
    return updated

