from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.deps import get_db
from app.models import employee, job_role, department, performance_review
from app.models.ai_career_path import AICareerPath
from app.crud import ai_career_path
from app.crud.ai_career_path import save_prediction_to_db
from app.ai.career_path_service import predict_career_path_row

router = APIRouter()

class EmployeeIDRequest(BaseModel):
    employee_id: int

@router.post("/career-path/predict")
def predict_career_path_for_employee(data: EmployeeIDRequest, db: Session = Depends(get_db)):
    emp_id = data.employee_id

    # JOIN employee info for the given ID
    row = db.query(
        employee.Employee.employee_id,
        job_role.JobRole.title.label("current_role"),
        department.Department.department_name,
        employee.Employee.date_of_joining,
        performance_review.PerformanceReview.rating,
        performance_review.PerformanceReview.promotion_recommendation
    ).join(
        job_role.JobRole, job_role.JobRole.job_role_id == employee.Employee.job_role_id
    ).join(
        department.Department, department.Department.department_id == employee.Employee.department_id
    ).join(
        performance_review.PerformanceReview,
        performance_review.PerformanceReview.employee_id == employee.Employee.employee_id
    ).filter(
        employee.Employee.employee_id == emp_id
    ).first()

    if not row:
        raise HTTPException(status_code=404, detail="Employee or review data not found")

    result = predict_career_path_row(
        current_role=row.current_role,
        department=row.department_name,
        doj=row.date_of_joining,
        rating=row.rating,
        promotion_recommendation=row.promotion_recommendation
    )

    save_prediction_to_db(
        db,
        employee_id=row.employee_id,
        role=result["recommended_role"],
        courses=result["suggested_courses"],
        growth_years=result["predicted_growth_years"]
    )

    return {
        "status": "success",
        "employee_id": row.employee_id,
        "predicted": True
    }


@router.post("/career-path/batch-update")
def batch_generate_paths(db: Session = Depends(get_db)):
    results = db.query(
        employee.Employee.employee_id,
        job_role.JobRole.title.label("current_role"),
        department.Department.department_name,
        employee.Employee.date_of_joining,
        performance_review.PerformanceReview.rating,
        performance_review.PerformanceReview.promotion_recommendation
    ).join(
        job_role.JobRole, job_role.JobRole.job_role_id == employee.Employee.job_role_id
    ).join(
        department.Department, department.Department.department_id == employee.Employee.department_id
    ).join(
        performance_review.PerformanceReview,
        performance_review.PerformanceReview.employee_id == employee.Employee.employee_id
    ).all()

    updated = 0
    for row in results:
        try:
            result = predict_career_path_row(
                current_role=row.current_role,
                department=row.department_name,
                doj=row.date_of_joining,
                rating=row.rating,
                promotion_recommendation=row.promotion_recommendation
            )
            ai_career_path.save_prediction_to_db(
                db,
                employee_id=row.employee_id,
                role=result["recommended_role"],
                courses=result["suggested_courses"],
                growth_years=result["predicted_growth_years"]
            )
            updated += 1
        except Exception as e:
            print(f"Skipping {row.employee_id}: {e}")

    return {"status": "success", "updated_count": updated}
