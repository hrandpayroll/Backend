from sqlalchemy import Column, Integer, Float, DateTime, String, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

class AIMoodIndex(Base):
    __tablename__ = "ai_mood_index"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=True)
    mood_score = Column(Float, nullable=False)
    recorded_on = Column(DateTime, nullable=False)
    source = Column(String(255), nullable=False)  # E.g. "notifications+reviews+letters"

    employee = relationship("Employee", back_populates="mood_entries")
