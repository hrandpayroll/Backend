from sqlalchemy import Column, Integer, String, ForeignKey, Boolean, DateTime
from sqlalchemy.orm import relationship
from app.database import Base

class Letter(Base):
    __tablename__ = "letters"

    letter_id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=False)
    type = Column(String(255), nullable=False)  # Offer, Exit, Increment
    subject = Column(String(255), nullable=False)
    generated_on = Column(DateTime, nullable=False)
    signed = Column(Boolean, default=False)
    doc_link = Column(String(255))

    employee = relationship("Employee", back_populates="letters")
