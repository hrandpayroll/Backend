from sqlalchemy import Column, Integer, String, ForeignKey
from app.database import Base

class AICareerPath(Base):
    __tablename__ = "ai_career_path"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"))
    recommended_role = Column(String)
    suggested_courses = Column(String)
    predicted_growth_years = Column(Integer)
