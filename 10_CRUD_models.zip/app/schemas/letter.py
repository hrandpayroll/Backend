from pydantic import BaseModel
from datetime import datetime

class LetterBase(BaseModel):
    employee_id: int
    type: str  # Offer, Exit, Increment
    subject: str
    generated_on: datetime
    signed: bool
    doc_link: str

class LetterCreate(LetterBase):
    pass

class LetterResponse(LetterBase):
    letter_id: int

    class Config:
        orm_mode = True

from typing import Optional

class LetterUpdate(BaseModel):
    subject: Optional[str] = None
    type: Optional[str] = None
    generated_on: Optional[datetime] = None
    signed: Optional[bool] = None
    doc_link: Optional[str] = None

    class Config:
        from_attributes = True

