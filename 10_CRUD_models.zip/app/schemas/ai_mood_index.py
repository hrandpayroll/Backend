from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class AIMoodIndexCreate(BaseModel):
    pass  # No input needed — everything is derived from employee_id in path

class AIMoodIndexResponse(BaseModel):
    id: int
    employee_id: Optional[int]
    mood_score: float
    recorded_on: datetime

    class Config:
        orm_mode = True
        
from typing import Optional

class AIMoodIndexUpdate(BaseModel):
    mood_score: Optional[float] = None
    recorded_on: Optional[datetime] = None

    class Config:
        from_attributes = True
