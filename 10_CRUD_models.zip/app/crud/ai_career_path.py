from sqlalchemy.orm import Session
from app.models.ai_career_path import AICareerPath

def save_prediction_to_db(db: Session, employee_id, role, courses, growth_years):
    obj = db.query(AICareerPath).filter_by(employee_id=employee_id).first()
    if obj:
        obj.recommended_role = role
        obj.suggested_courses = courses
        obj.predicted_growth_years = growth_years
    else:
        obj = AICareerPath(
            employee_id=employee_id,
            recommended_role=role,
            suggested_courses=courses,
            predicted_growth_years=growth_years
        )
        db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj

