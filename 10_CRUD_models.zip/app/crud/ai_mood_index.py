from sqlalchemy.orm import Session
from datetime import datetime
from app.models.ai_mood_index import AIMoodIndex
from app.ai.mood_index_model import calculate_final_mood_score

def create_ai_mood_index(db: Session, employee_id: int) -> AIMoodIndex:
    score = calculate_final_mood_score(employee_id, db)

    entry = AIMoodIndex(
        employee_id=employee_id,
        mood_score=score,
        recorded_on=datetime.utcnow()
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry

def update_ai_mood_index(db: Session, mood_id: int, updates: dict):
    mood_entry = db.query(AIMoodIndex).filter(AIMoodIndex.id == mood_id).first()
    if not mood_entry:
        return None
    for key, value in updates.items():
        setattr(mood_entry, key, value)
    db.commit()
    db.refresh(mood_entry)
    return mood_entry

def delete_ai_mood_index(db: Session, mood_id: int):
    mood_entry = db.query(AIMoodIndex).filter(AIMoodIndex.id == mood_id).first()
    if not mood_entry:
        return None
    db.delete(mood_entry)
    db.commit()
    return mood_entry

from app.models import Notification, Letter, PerformanceReview
from app.ai.mood_index_model import calculate_final_mood_score

def recalculate_ai_mood_index(db: Session, mood_id: int):
    # Get the existing mood entry
    entry = db.query(AIMoodIndex).filter(AIMoodIndex.id == mood_id).first()
    if not entry:
        return None

    emp_id = entry.employee_id

    # Fetch all text for this employee
    notif_msgs = [n.message for n in db.query(Notification).filter_by(employee_id=emp_id).all()]
    letter_msgs = [l.subject for l in db.query(Letter).filter_by(employee_id=emp_id).all()]
    review_msgs = [r.strengths + " " + r.areas_of_improvement for r in db.query(PerformanceReview).filter_by(employee_id=emp_id).all()]
    all_text = notif_msgs + letter_msgs + review_msgs

    if not all_text:
        return None

    # Recalculate mood score
    new_score = calculate_final_mood_score(all_text, db)

    # Update mood entry
    entry.mood_score = new_score
    entry.recorded_on = datetime.utcnow()
    db.commit()
    db.refresh(entry)
    return entry