from sqlalchemy.orm import Session
from app.models.letter import Letter
from app.schemas.letter import LetterCreate

def create_letter(db: Session, letter: LetterCreate) -> Letter:
    db_letter = Letter(**letter.dict())
    db.add(db_letter)
    db.commit()
    db.refresh(db_letter)
    return db_letter

def get_letters_by_employee(db: Session, employee_id: int):
    return db.query(Letter).filter(Letter.employee_id == employee_id).all()

def update_letter(db: Session, letter_id: int, updates: dict):
    letter = db.query(Letter).filter(Letter.letter_id == letter_id).first()
    if not letter:
        return None
    for key, value in updates.items():
        setattr(letter, key, value)
    db.commit()
    db.refresh(letter)
    return letter

