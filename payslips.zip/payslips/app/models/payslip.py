from sqlalchemy import Column, Integer, String, Date, DateTime, ForeignKey
from app.database import Base
from sqlalchemy.sql import func

class Payslip(Base):
    __tablename__ = "payslips"

    payslip_id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=False)
    month = Column(Date, nullable=False)
    generated_on = Column(DateTime, server_default=func.now())
    blockchain_hash = Column(String(255), nullable=False)
    pdf_link = Column(String(255), nullable=False)
