from pydantic import BaseModel
from datetime import date, datetime

class PayslipCreate(BaseModel):
    employee_id: int
    month: date
    blockchain_hash: str
    pdf_link: str

class PayslipUpdate(BaseModel):
    blockchain_hash: str
    pdf_link: str

class PayslipResponse(PayslipCreate):
    payslip_id: int
    generated_on: datetime

    class Config:
        from_attributes = True
