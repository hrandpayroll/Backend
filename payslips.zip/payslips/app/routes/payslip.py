from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models.payslip import Payslip
from app.schemas.payslip import PayslipCreate, PayslipUpdate, PayslipResponse

router = APIRouter(prefix="/payslip", tags=["Payslip"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Create
@router.post("/", response_model=PayslipResponse)
def create_payslip(payslip: PayslipCreate, db: Session = Depends(get_db)):
    new_payslip = Payslip(**payslip.dict())
    db.add(new_payslip)
    db.commit()
    db.refresh(new_payslip)
    return new_payslip

# Read all
@router.get("/", response_model=list[PayslipResponse])
def get_all_payslips(db: Session = Depends(get_db)):
    return db.query(Payslip).all()

# Read by ID
@router.get("/{payslip_id}", response_model=PayslipResponse)
def get_payslip(payslip_id: int, db: Session = Depends(get_db)):
    payslip = db.query(Payslip).filter(Payslip.payslip_id == payslip_id).first()
    if not payslip:
        raise HTTPException(status_code=404, detail="Payslip not found")
    return payslip

# Update
@router.put("/{payslip_id}", response_model=PayslipResponse)
def update_payslip(payslip_id: int, updated: PayslipUpdate, db: Session = Depends(get_db)):
    payslip = db.query(Payslip).filter(Payslip.payslip_id == payslip_id).first()
    if not payslip:
        raise HTTPException(status_code=404, detail="Payslip not found")
    for key, value in updated.dict().items():
        setattr(payslip, key, value)
    db.commit()
    db.refresh(payslip)
    return payslip

# Delete
@router.delete("/{payslip_id}")
def delete_payslip(payslip_id: int, db: Session = Depends(get_db)):
    payslip = db.query(Payslip).filter(Payslip.payslip_id == payslip_id).first()
    if not payslip:
        raise HTTPException(status_code=404, detail="Payslip not found")
    db.delete(payslip)
    db.commit()
    return {"message": f"Payslip {payslip_id} deleted successfully."}
