from fastapi import FastAPI
from app.database import Base, engine
from app.routes import payslip
app = FastAPI(title="AI Tools API", version="1.0")


Base.metadata.create_all(bind=engine)

@app.get("/")
def welcome():
    return {"message": "Welcome to the AI Tools API"}


app.include_router(payslip.router)


