from sqlalchemy import Column, Integer, String, Date, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.database import Base

class Employee(Base):
    __tablename__ = "employees"

    employee_id = Column(Integer, primary_key=True, index=True)
    first_name = Column(String(255))
    last_name = Column(String(255))
    email = Column(String(255), unique=True, nullable=False)
    phone_number = Column(String(255))
    department_id = Column(Integer, ForeignKey("departments.department_id"))
    job_role_id = Column(Integer, ForeignKey("job_roles.job_role_id"))
    date_of_joining = Column(Date)
    status = Column(String(50))  # "Active", "On Leave", "Resigned"
    manager_id = Column(Integer, ForeignKey("employees.employee_id"))
    aadhaar_number = Column(String(255))
    bank_account_number = Column(String(255))
    pan_number = Column(String(255))
    profile_picture = Column(Text)

    # Optional: set up relationships (if needed)
    # department = relationship("Department", back_populates="employees")
    # job_role = relationship("JobRole", back_populates="employees")
