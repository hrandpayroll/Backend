from fastapi import FastAPI
from app.database import Base, engine
from app.models import employee  # This is needed to register the Employee table

from app.routes import employee as employee_routes

app = FastAPI()

# # Create the tables in the DB (if they don't exist)
# Base.metadata.create_all(bind=engine)

# Root endpoint
@app.get("/")
def welcome():
    return {"message": "Welcome to Alpixn HR API"}

# Include the employee API routes
app.include_router(employee_routes.router)

