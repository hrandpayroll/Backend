from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import date

class EmployeeBase(BaseModel):
    first_name: str
    last_name: str
    email: EmailStr
    phone_number: Optional[str] = None
    department_id: Optional[int] = None
    job_role_id: Optional[int] = None
    date_of_joining: Optional[date] = None
    status: Optional[str] = None  # Should be 'Active', 'On Leave', or 'Resigned'
    manager_id: Optional[int] = None
    aadhaar_number: Optional[str] = None
    bank_account_number: Optional[str] = None
    pan_number: Optional[str] = None
    profile_picture: Optional[str] = None

class EmployeeCreate(EmployeeBase):
    pass

class EmployeeOut(EmployeeBase):
    employee_id: int

    class Config:
        orm_mode = True  # Enables conversion from SQLAlchemy to JSON
