from pydantic import BaseModel
from datetime import datetime

class AttendanceCreate(BaseModel):
    employee_id: int
    check_in: datetime
    check_out: datetime

class AttendanceResponse(AttendanceCreate):
    id: int

    class Config:
        from_attributes=True
