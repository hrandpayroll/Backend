from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models.leave import Leave
from app.schemas.leave import LeaveCreate, LeaveResponse

router = APIRouter(prefix="/leave", tags=["Leave"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=LeaveResponse)
def apply_leave(leave: LeaveCreate, db: Session = Depends(get_db)):
    leave_db = Leave(**leave.dict())
    db.add(leave_db)
    db.commit()
    db.refresh(leave_db)
    return leave_db


@router.get("/", response_model=list[LeaveResponse])
def get_leaves(db: Session = Depends(get_db)):
    return db.query(Leave).all()