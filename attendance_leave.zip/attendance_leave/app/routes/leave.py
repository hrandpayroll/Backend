from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models.leave import Leave
from app.schemas.leave import LeaveCreate, LeaveResponse

router = APIRouter(prefix="/leave", tags=["Leave"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=LeaveResponse)
def apply_leave(leave: LeaveCreate, db: Session = Depends(get_db)):
    leave_db = Leave(**leave.dict())
    db.add(leave_db)
    db.commit()
    db.refresh(leave_db)
    return leave_db


@router.get("/", response_model=list[LeaveResponse])
def get_leaves(db: Session = Depends(get_db)):
    return db.query(Leave).all()


@router.get("/employee/{employee_id}", response_model=list[LeaveResponse])
def get_leaves_by_employee(employee_id: int, db: Session = Depends(get_db)):
    leaves = db.query(Leave).filter(Leave.employee_id == employee_id).all()
    if not leaves:
        raise HTTPException(status_code=404, detail="No leaves found for this employee")
    return leaves


@router.put("/{leave_id}", response_model=LeaveResponse)
def update_leave_status(leave_id: int, status: str = Query(...), db: Session = Depends(get_db)):
    leave = db.query(Leave).filter(Leave.leave_id == leave_id).first()
    if not leave:
        raise HTTPException(status_code=404, detail="Leave not found")
    leave.status = status
    db.commit()
    db.refresh(leave)
    return leave


@router.delete("/{leave_id}")
def delete_leave(leave_id: int, db: Session = Depends(get_db)):
    leave = db.query(Leave).filter(Leave.leave_id == leave_id).first()
    if not leave:
        raise HTTPException(status_code=404, detail="Leave not found")
    db.delete(leave)
    db.commit()
    return {"message": f"Leave ID {leave_id} deleted successfully."}
