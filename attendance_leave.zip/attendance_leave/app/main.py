from fastapi import FastAPI
from app.routes import leave, attendance
from app.database import Base,engine

app = FastAPI()

Base.metadata.create_all(bind=engine)

@app.get("/")
def welcome():
    return{"message":"welcome"}


app.include_router(leave.router)
app.include_router(attendance.router)

