from sqlalchemy import Column, Integer, DateTime, ForeignKey,String,Boolean
from app.database import Base
from sqlalchemy import func

class Attendance(Base):
    __tablename__ = "attendance"

    attendance_id=Column(Integer,primary_key=True,index=True)
    employee_id = Column(Integer,ForeignKey("employees.employee_id") ,nullable=False)
    check_in = Column(DateTime(timezone=True),server_default=func.now())
    check_out = Column(DateTime)
    location=Column(String)
    face_id_verified=Column(Boolean,default=False)
