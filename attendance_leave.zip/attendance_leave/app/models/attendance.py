from sqlalchemy import Column, Integer, DateTime, ForeignKey,String,Boolean
from app.database import Base
from datetime import datetime

class Attendance(Base):
    __tablename__ = "attendance"

    attendance_id=Column(Integer,primary_key=True,index=True)
    employee_id = Column(Integer, nullable=False)
    check_in = Column(DateTime, default=datetime)
    check_out = Column(DateTime)
    location=Column(String)
    face_id_verified=Column(Boolean,default=False)
