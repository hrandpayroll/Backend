from sqlalchemy import Column, Integer, String, Date, ForeignKey,VARCHAR
from app.database import Base

class Leave(Base):
    __tablename__ = "leave"

    leave_id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, nullable=False)
    leave_type = Column(String, nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    status = Column(String, default="Pending")
    type=Column(VARCHAR,nullable=False)
    
