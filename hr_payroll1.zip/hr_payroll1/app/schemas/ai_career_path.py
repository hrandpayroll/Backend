from pydantic import BaseModel
from typing import Optional

class AICareerPathBase(BaseModel):
    recommended_role: Optional[str]
    suggested_courses: Optional[str]
    predicted_growth_years: Optional[int]

class AICareerPathCreate(AICareerPathBase):
    employee_id: int

class AICareerPathUpdate(AICareerPathBase):
    employee_id: int

class EmployeeCareerOut(BaseModel):
    first_name : str
    last_name : str

class AICareerPathOut(AICareerPathBase):
    id: int
    employee: EmployeeCareerOut

    class Config:
        from_attributes = True
