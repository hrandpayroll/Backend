from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import date

class DepartOut(BaseModel):
    department_id : int
    department_name : str
    
    class Config:
        from_attributes = True 

class JobOut(BaseModel):
    title : str
    level : str

    class Config:
        from_attributes = True 

class ManagerOut(BaseModel):
    employee_id : int
    first_name : str
    last_name : str    

    class Config:
        from_attributes = True 

class EmployeeBase(BaseModel):
    first_name: str
    last_name: str
    email: EmailStr
    phone_number: str
    date_of_joining: date 
    status: str  # Should be 'Active', 'On Leave', or 'Resigned'
    manager_id: Optional[int] = None
    aadhaar_number: Optional[str] = None
    bank_account_number: Optional[str] = None
    pan_number: Optional[str] = None
    profile_picture: Optional[str] = None

class EmployeeCreate(EmployeeBase):
    department_id: int
    job_role_id: int

class EmployeeUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone_number: Optional[str] = None
    date_of_joining: Optional[date] = None
    status: Optional[str] = None
    manager_id: Optional[int] = None
    aadhaar_number: Optional[str] = None
    bank_account_number: Optional[str] = None
    pan_number: Optional[str] = None
    profile_picture: Optional[str] = None
    department_id: Optional[int] = None
    job_role_id: Optional[int] = None


class EmployeeOut(EmployeeBase):
    employee_id: int
    department: DepartOut
    job_role: JobOut
    manager : ManagerOut

    class Config:
        from_attributes = True 