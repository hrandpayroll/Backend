from typing import Optional
from pydantic import BaseModel

class JobRoleBase(BaseModel):
    title: str
    level: str

class JobRoleCreate(JobRoleBase):
    pass

class JobRoleUpdate(BaseModel):
    title : Optional[str] = None
    level : Optional[str] = None

class JobRoleRead(JobRoleBase):
    job_role_id: int

    class Config:
        from_attributes = True
