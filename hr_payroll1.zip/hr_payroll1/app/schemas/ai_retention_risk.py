from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class AiRetentionRiskBase(BaseModel):
    employee_id: int
    risk_score: Optional[float] = None
    evaluated_on: Optional[datetime] = None

class AiRetentionRiskCreate(AiRetentionRiskBase):
    pass

class AiRetentionRiskUpdate(BaseModel):
    risk_score: Optional[float] = None
    evaluated_on: Optional[datetime] = None

class AiRetentionRiskOut(AiRetentionRiskBase):
    id: int

    class Config:
        from_attributes = True
