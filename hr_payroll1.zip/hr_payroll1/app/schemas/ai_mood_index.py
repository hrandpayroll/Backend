from enum import Enum
from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class MoodSource(str, Enum):
    chat = "chat"
    email = "email"
    survey = "survey"


class AIMoodBase(BaseModel):
    mood_score: float
    recorded_on: datetime
    source: MoodSource


class AIMoodCreate(AIMoodBase):
    employee_id: int


class AIMoodUpdate(BaseModel):
    employee_id: Optional[int] = None
    mood_score: Optional[float] = None
    recorded_on: Optional[datetime] = None
    source: Optional[MoodSource] = None

class EmployeeMood(BaseModel):
    employee_id : int
    first_name : str
    last_name : str

class AIMoodResponse(AIMoodBase):
    id: int
    employee : EmployeeMood

    class Config:
        from_attributes = True
