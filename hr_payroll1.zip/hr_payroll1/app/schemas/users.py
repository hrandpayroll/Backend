from pydantic import BaseModel, EmailStr
from typing import Optional

class UserBase(BaseModel):
    email: EmailStr

class UserCreate(UserBase):
    password: str
    role_id: int

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    password: Optional[str] = None
    role_id: Optional[int] = None

class RoleOut(BaseModel):
    role_id: int
    name: str 

class UserResponse(UserBase):
    user_id: int
    role: RoleOut  

    class Config:
        from_attributes = True
