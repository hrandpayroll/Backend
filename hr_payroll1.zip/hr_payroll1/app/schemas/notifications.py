from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class NotificationBase(BaseModel):
    message: str
    is_read: Optional[bool] = False

class NotificationCreate(NotificationBase):
    employee_id: int

class NotificationUpdate(BaseModel):
    is_read: bool

class NotificationOut(NotificationBase):
    notif_id: int
    employee_id: int
    created_at: datetime

    class Config:
        from_attributes = True
