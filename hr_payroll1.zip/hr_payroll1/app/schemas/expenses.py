# app/schemas/expenses.py
from enum import Enum
from pydantic import BaseModel
from datetime import date
from typing import Optional

class ExpensesStatus(str, Enum):
    APPROVED = "Approved"
    REJECTED = "Rejected"
    PENDING = "Pending"

class ExpenseBase(BaseModel):
    category: str
    amount: float
    date_submitted: date
    status: ExpensesStatus
    receipt_link: str

class ExpenseCreate(ExpenseBase):
    employee_id: int

class ExpenseUpdate(BaseModel):
    employee_id : Optional[int] = None
    category: Optional[str] = None
    amount: Optional[float] = None
    date_submitted: Optional[date] = None
    status: Optional[ExpensesStatus] = None
    receipt_link: Optional[str] = None

class EmployeeExpense(BaseModel):
    employee_id : int
    first_name : str
    last_name : str

class ExpenseResponse(ExpenseBase):
    expense_id: int
    employee : EmployeeExpense

    class Config:
        from_attributes = True
