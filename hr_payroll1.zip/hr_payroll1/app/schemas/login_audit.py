from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class LoginAuditBase(BaseModel):
    user_id: int
    timestamp: datetime
    ip_address: Optional[str] = None
    device_type: Optional[str] = None
    success: bool

class LoginAuditCreate(LoginAuditBase):
    pass

class LoginAuditOut(LoginAuditBase):
    audit_id: int

    class Config:
        from_attributes = True
