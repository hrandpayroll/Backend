from pydantic import BaseModel

class SettingBase(BaseModel):
    setting_key: str
    value: str
    module_name: str

class SettingCreate(SettingBase):
    pass

class SettingUpdate(BaseModel):
    setting_key: str | None = None
    value: str | None = None
    module_name: str | None = None

class SettingOut(SettingBase):
    setting_id: int

    class Config:
        orm_mode = True
