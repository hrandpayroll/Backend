from pydantic import BaseModel
from datetime import date
from typing import Optional
from enum import Enum

class LeaveType(str, Enum):
    CASUAL = 'Casual'
    EARNED = 'Earned'
    SICK = 'Sick'

class LeaveStatus(str, Enum):
    APPROVED = 'Approved'
    REJECTED = 'Rejected'
    PENDING = 'Pending'

class LeaveBase(BaseModel):
    start_date: date
    end_date: date
    leave_type: LeaveType
    status: LeaveStatus


class LeaveCreate(LeaveBase):
    employee_id: int


class LeaveUpdate(BaseModel):
    employee_id: Optional[int] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    leave_type: Optional[LeaveType] = None
    status: Optional[LeaveStatus] = None


class EmployeeOut(BaseModel):
    employee_id: int
    first_name: str
    last_name: str



class LeaveResponse(LeaveBase):
    leave_id: int
    employee: EmployeeOut

    class Config:
        from_attributes = True  