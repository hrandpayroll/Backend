from typing import Optional
from pydantic import BaseModel
from datetime import date, datetime

class PayslipBase(BaseModel):
    month: date
    blockchain_hash: str
    pdf_link: str

class PayslipCreate(PayslipBase):
    employee_id: int
    

class PayslipUpdate(BaseModel):
    employee_id : Optional[int] = None
    month: Optional[date] = None
    blockchain_hash: Optional[str] = None
    pdf_link: Optional[str] = None

class EmployeePaySlipOut(BaseModel):
    employee_id : int
    first_name : str
    last_name : str

class PayslipResponse(PayslipBase):
    payslip_id: int
    generated_on: datetime
    employee : EmployeePaySlipOut

    class Config:
        from_attributes = True