from pydantic import BaseModel, Field
from typing import Optional
from datetime import date
from typing import Annotated

class PerformanceBase(BaseModel):
    review_period: date
    rating: Annotated[int, Field(ge=1, le=5)]
    strengths: str
    areas_of_improvement: str
    promotion_recommendation: bool

class PerformanceCreate(PerformanceBase):
    employee_id: int
    reviewer_id: int

class PerformanceUpdate(BaseModel):
    employee_id: Optional[int] = None
    reviewer_id: Optional[int] = None
    review_period: Optional[date] = None
    rating: Optional[Annotated[int, Field(ge=1, le=5)]] = None
    strengths: Optional[str] = None
    areas_of_improvement: Optional[str] = None
    promotion_recommendation: Optional[bool] = None

class EmployeeInfo(BaseModel):
    employee_id: int
    first_name: str
    last_name: str

class PerformanceResponse(PerformanceBase):
    review_id: int
    employee: EmployeeInfo
    reviewer: EmployeeInfo

    class Config:
        from_attributes = True
