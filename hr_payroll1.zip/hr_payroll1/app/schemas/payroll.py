from pydantic import BaseModel
from datetime import date
from typing import Optional

class PayrollBase(BaseModel):
    month: date
    base_salary: float
    bonus: float
    tax_deducted: float
    net_payable: float
    status: str

class PayrollCreate(PayrollBase):
    employee_id: int

class PayrollUpdate(BaseModel):
    employee_id: Optional[int] = None
    month: Optional[date] = None
    base_salary: Optional[float] = None
    bonus: Optional[float] = None
    tax_deducted: Optional[float] = None
    net_payable: Optional[float] = None
    status: Optional[str] = None

class EmployeePayOut(BaseModel):
    employee_id : int
    first_name : str
    last_name : str

class PayrollOut(PayrollBase):
    payroll_id: int
    employee_details : EmployeePayOut

    class Config:
        from_attributes = True