from pydantic import BaseModel
from enum import Enum
from datetime import datetime
from typing import Optional

# Separate enum for Pydantic
class LetterType(str, Enum):
    OFFER = "Offer"
    EXIT = "Exit"
    INCREMENT = "Increment"

class LetterBase(BaseModel):
    employee_id: int
    letter_type: LetterType
    generated_on: Optional[datetime] = None
    signed: Optional[bool] = False
    doc_link: Optional[str] = None  # Nullable

class LetterCreate(LetterBase):
    pass

class LetterUpdate(BaseModel):
    letter_type: Optional[LetterType] = None
    generated_on: Optional[datetime] = None
    signed: Optional[bool] = None
    doc_link: Optional[str] = None

class LetterOut(LetterBase):
    letter_id: int

    class Config:
        from_attributes = True
