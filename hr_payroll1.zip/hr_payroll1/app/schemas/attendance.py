from pydantic import BaseModel
from datetime import datetime, date
from typing import Optional


class AttendanceBase(BaseModel):
    attendance_date: date
    clock_in: datetime
    clock_out: datetime
    location: str
    face_id_verified: bool


class AttendanceCreate(AttendanceBase):
    employee_id: int


class AttendanceUpdate(BaseModel):
    employee_id: Optional[int] = None
    attendance_date: Optional[date] = None
    clock_in: Optional[datetime] = None
    clock_out: Optional[datetime] = None
    location: Optional[str] = None
    face_id_verified: Optional[bool] = None


class AttendanceEmployeeOut(BaseModel):
    employee_id: int
    first_name: str
    last_name: str


class AttendanceResponse(AttendanceBase):
    attendance_id: int
    employee: AttendanceEmployeeOut  

    class Config:
        from_attributes = True