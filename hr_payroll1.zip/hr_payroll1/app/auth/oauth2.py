import os
from fastapi import Depends, status, HTTPException
import jwt
from jwt.exceptions import PyJWTError
from dotenv import load_dotenv
from datetime import datetime, timedelta, timezone
from fastapi.security.oauth2 import OAuth2PasswordBearer
from app.schemas.login import Token
load_dotenv()

SECRET_KEY = os.getenv('JWT_KEY')
ALGORITHM = os.getenv('ALGORITHM')
EXPIRATION = os.getenv('EXPIRATION')

oauth_schema = OAuth2PasswordBearer(tokenUrl='login')

def create_access_token(data:dict):
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=int(EXPIRATION))
    to_encode["exp"]= expire
    encoded_jwt = jwt.encode(to_encode,key=SECRET_KEY,algorithm=ALGORITHM)
    return encoded_jwt


def verify_access_token(token:str,credential_exception):
    try:
        payload = jwt.decode(token,key=SECRET_KEY,algorithms=[ALGORITHM])
        id : int =  payload['user_id']
        if id is None :
            raise credential_exception
    except PyJWTError:
        raise credential_exception
    return id


def current_user(token:str=Depends(oauth_schema)):
    credential_exception = HTTPException(
                                            status_code=status.HTTP_401_UNAUTHORIZED,
                                            detail="Could not validate credentials",
                                            headers={"WWW-Authenticate": "Bearer"})
    
    return verify_access_token(token=token,credential_exception=credential_exception)

