from fastapi import APIRouter, status, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.department import Department
from app.schemas.department import DepartmentCreate, DepartmentRead
from typing import List


router = APIRouter(
    prefix="/department",
    tags=["Departments"]
)


@router.post("/", status_code=status.HTTP_201_CREATED, response_model=DepartmentRead)
def create_department(dept: DepartmentCreate, db: Session = Depends(get_db)):
    db_dept = Department(**dept.model_dump())
    db.add(db_dept)
    db.commit()
    db.refresh(db_dept)
    return db_dept



@router.get("/{dept_id}", response_model=DepartmentRead)
def read_department(dept_id: int, db: Session = Depends(get_db)):
    dept = db.query(Department).filter(Department.department_id == dept_id).first()
    if not dept:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Department not found")
    return dept



@router.get("/", response_model=List[DepartmentRead])
def get_all_departments(db: Session = Depends(get_db)):
    return db.query(Department).all()




@router.put("/{dept_id}", response_model=DepartmentRead)
def update_department(dept_id: int, updated: DepartmentCreate, db: Session = Depends(get_db)):
    dept = db.query(Department).filter(Department.department_id == dept_id).first()
    if not dept:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Department not found")
    for key, value in updated.model_dump().items():
        setattr(dept, key, value)
    db.commit()
    db.refresh(dept)
    return dept



@router.delete("/{dept_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_department(dept_id: int, db: Session = Depends(get_db)):
    dept = db.query(Department).filter(Department.department_id == dept_id).first()
    if not dept:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Department not found")
    db.delete(dept)
    db.commit()
    

