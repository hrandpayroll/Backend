from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.models.ai_retention_risk import AiRetentionRisk
from app.schemas.ai_retention_risk import (
    AiRetentionRiskCreate,
    AiRetentionRiskUpdate,
    AiRetentionRiskOut
)

router = APIRouter(
    prefix="/retention-risk",
    tags=["AI Retention Risk"]
)

@router.post("/", response_model=AiRetentionRiskOut, status_code=status.HTTP_201_CREATED)
def create_risk(payload: AiRetentionRiskCreate, db: Session = Depends(get_db)):
    risk = AiRetentionRisk(**payload.dict())
    db.add(risk)
    db.commit()
    db.refresh(risk)
    return risk

@router.get("/", response_model=List[AiRetentionRiskOut])
def get_all_risks(db: Session = Depends(get_db)):
    return db.query(AiRetentionRisk).all()

@router.get("/{risk_id}", response_model=AiRetentionRiskOut)
def get_risk(risk_id: int, db: Session = Depends(get_db)):
    risk = db.query(AiRetentionRisk).filter(AiRetentionRisk.id == risk_id).first()
    if not risk:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Risk record not found")
    return risk

@router.put("/{risk_id}", response_model=AiRetentionRiskOut)
def update_risk(risk_id: int, payload: AiRetentionRiskUpdate, db: Session = Depends(get_db)):
    risk = db.query(AiRetentionRisk).filter(AiRetentionRisk.id == risk_id).first()
    if not risk:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Risk record not found")
    for key, value in payload.dict(exclude_unset=True).items():
        setattr(risk, key, value)
    db.commit()
    db.refresh(risk)
    return risk

@router.delete("/{risk_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_risk(risk_id: int, db: Session = Depends(get_db)):
    risk = db.query(AiRetentionRisk).filter(AiRetentionRisk.id == risk_id).first()
    if not risk:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Risk record not found")
    db.delete(risk)
    db.commit()
