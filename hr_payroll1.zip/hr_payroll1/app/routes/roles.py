from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models.roles import Role
from app.schemas.roles import RoleCreate, RoleUpdate, RoleResponse

router = APIRouter(prefix="/roles",
                   tags=["Roles"])



@router.post("/", response_model=RoleResponse, status_code=status.HTTP_201_CREATED)
def create_role(role: RoleCreate, db: Session = Depends(get_db)):
    existing = db.query(Role).filter(Role.name == role.name).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Role already exists."
        )
    new_role = Role(**role.model_dump())
    db.add(new_role)
    db.commit()
    db.refresh(new_role)
    return new_role



@router.get("/", response_model=List[RoleResponse])
def list_roles(db: Session = Depends(get_db)):
    return db.query(Role).all()



@router.get("/{role_id}", response_model=RoleResponse)
def get_role(role_id: int, db: Session = Depends(get_db)):
    role = db.query(Role).filter(Role.role_id == role_id).first()
    if not role:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail="Role not found")
    return role



@router.put("/{role_id}", response_model=RoleResponse)
def update_role(role_id: int, update: RoleUpdate, db: Session = Depends(get_db)):
    role = db.query(Role).filter(Role.role_id == role_id).first()
    if not role:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Role not found")
    
    duplicate = db.query(Role).filter(
        Role.name == update.name,
        Role.role_id != role_id
    ).first()

    if duplicate:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Role name already exists.")

    role.name = update.name
    db.commit()
    db.refresh(role)
    return role



@router.delete("/{role_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_role(role_id: int, db: Session = Depends(get_db)):
    role = db.query(Role).filter(Role.role_id == role_id).first()
    if not role:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail="Role not found")
    db.delete(role)
    db.commit()
