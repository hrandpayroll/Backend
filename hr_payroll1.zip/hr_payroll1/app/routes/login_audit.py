from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.models.login_audit import LoginAudit
from app.schemas.login_audit import LoginAuditCreate, LoginAuditOut

router = APIRouter(
    prefix="/login-audit",
    tags=["Login Audit"]
)



@router.post("/", response_model=LoginAuditOut, status_code=status.HTTP_201_CREATED)
def create_login_audit(payload: LoginAuditCreate, db: Session = Depends(get_db)):
    audit = LoginAudit(**payload.dict())
    db.add(audit)
    db.commit()
    db.refresh(audit)
    return audit



@router.get("/", response_model=List[LoginAuditOut])
def get_all_login_audits(db: Session = Depends(get_db)):
    return db.query(LoginAudit).all()



@router.get("/{audit_id}", response_model=LoginAuditOut)
def get_login_audit(audit_id: int, db: Session = Depends(get_db)):
    audit = db.query(LoginAudit).filter(LoginAudit.audit_id == audit_id).first()
    if not audit:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Login audit record not found"
        )
    return audit



@router.put("/{audit_id}", response_model=LoginAuditOut)
def update_login_audit(audit_id: int, payload: LoginAuditCreate, db: Session = Depends(get_db)):
    audit = db.query(LoginAudit).filter(LoginAudit.audit_id == audit_id).first()
    if not audit:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Login audit record not found"
        )
    for key, value in payload.dict().items():
        setattr(audit, key, value)
    db.commit()
    db.refresh(audit)
    return audit



@router.delete("/{audit_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_login_audit(audit_id: int, db: Session = Depends(get_db)):
    audit = db.query(LoginAudit).filter(LoginAudit.audit_id == audit_id).first()
    if not audit:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Login audit record not found"
        )
    db.delete(audit)
    db.commit()

