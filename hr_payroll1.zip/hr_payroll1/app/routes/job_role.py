from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.job_role import JobRole
from app.schemas.job_role import JobRoleCreate, JobRoleRead, JobRoleUpdate

router = APIRouter(
    prefix="/job_role",
    tags=["Job Roles"]
)


@router.post("/", status_code=status.HTTP_201_CREATED, response_model=JobRoleRead)
def create_job_role(role: JobRoleCreate, db: Session = Depends(get_db)):
    db_role = JobRole(**role.model_dump())
    db.add(db_role)
    db.commit()
    db.refresh(db_role)
    return db_role



@router.get("/{role_id}", response_model=JobRoleRead)
def read_job_role(role_id: int, db: Session = Depends(get_db)):
    role = db.query(JobRole).filter(JobRole.job_role_id == role_id).first()
    if not role:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Job Role not found")
    return role



@router.get("/", response_model=List[JobRoleRead])
def get_all_job_roles(db: Session = Depends(get_db)):
    return db.query(JobRole).all()



@router.patch("/{role_id}", response_model=JobRoleRead)
def update_job_role(role_id: int, updated: JobRoleUpdate, db: Session = Depends(get_db)):
    updates = updated.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail='No fields provided')
    role = db.query(JobRole).filter(JobRole.job_role_id == role_id).first()
    if not role:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Job role not found")
    for key, value in updates.items():
        setattr(role, key, value)
    db.commit()
    db.refresh(role)
    return role



@router.delete("/{role_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_job_role(role_id: int, db: Session = Depends(get_db)):
    role = db.query(JobRole).filter(JobRole.job_role_id == role_id).first()
    if not role:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Job role not found")
    db.delete(role)
    db.commit()
    
