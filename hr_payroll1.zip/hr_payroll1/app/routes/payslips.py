from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.payslips import PaySlips
from app.schemas.payslips import PayslipCreate, PayslipUpdate, PayslipResponse

router = APIRouter(prefix="/payslip",
                   tags=["Payslip"])



@router.post("/", status_code=status.HTTP_201_CREATED, response_model=PayslipResponse)
def create_payslip(payslip: PayslipCreate, db: Session = Depends(get_db)):
    new_payslip = PaySlips(**payslip.model_dump())
    db.add(new_payslip)
    db.commit()
    db.refresh(new_payslip)
    return new_payslip



@router.get("/", response_model=List[PayslipResponse])
def get_all_payslips(db: Session = Depends(get_db)):
    return db.query(PaySlips).all()



@router.get("/{payslip_id}", response_model=PayslipResponse)
def get_payslip(payslip_id: int, db: Session = Depends(get_db)):
    payslip = db.query(PaySlips).filter(PaySlips.payslip_id == payslip_id).first()
    if not payslip:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Payslip not found")
    return payslip




@router.patch("/{payslip_id}", response_model=PayslipResponse)
def update_payslip(payslip_id: int, updated: PayslipUpdate, db: Session = Depends(get_db)):
    payslip = db.query(PaySlips).filter(PaySlips.payslip_id == payslip_id).first()
    if not payslip:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Payslip not found")
    updates = updated.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="No input fields received")
    for key, value in updates.items():
        setattr(payslip, key, value)
    db.commit()
    db.refresh(payslip)
    return payslip




@router.delete("/{payslip_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_payslip(payslip_id: int, db: Session = Depends(get_db)):
    payslip = db.query(PaySlips).filter(PaySlips.payslip_id == payslip_id).first()
    if not payslip:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Payslip not found")
    db.delete(payslip)
    db.commit()
    