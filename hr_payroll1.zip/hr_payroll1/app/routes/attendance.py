from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models.attendance import Attendance
from app.schemas.attendance import AttendanceCreate, AttendanceUpdate, AttendanceResponse

router = APIRouter(prefix="/attendance",
                   tags=["Attendance"])


@router.post("/", response_model=AttendanceResponse, status_code=status.HTTP_201_CREATED)
def mark_attendance(record: AttendanceCreate, db: Session = Depends(get_db)):
    attendance = Attendance(**record.model_dump())
    db.add(attendance)
    db.commit()
    db.refresh(attendance)
    return attendance



@router.get("/", response_model=List[AttendanceResponse])
def list_attendance(db: Session = Depends(get_db)):
    return db.query(Attendance).all()



@router.get("/{id}", response_model=AttendanceResponse)
def get_attendance(id: int, db: Session = Depends(get_db)):
    attendance = db.query(Attendance).filter(Attendance.attendance_id == id).first()
    if not attendance:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Attendance record not found")
    return attendance



@router.patch("/{id}", response_model=AttendanceResponse)
def update_checkout(id: int, update: AttendanceUpdate, db: Session = Depends(get_db)):
    attendance = db.query(Attendance).filter(Attendance.attendance_id == id).first()
    if not attendance:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Attendance record not found")

    updates = update.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="No fields to update")

    for field, value in updates.items():
        setattr(attendance, field, value)

    db.commit()
    db.refresh(attendance)
    return attendance



@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_attendance(id: int, db: Session = Depends(get_db)):
    attendance = db.query(Attendance).filter(Attendance.attendance_id == id).first()
    if not attendance:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail="Attendance record not found")
    db.delete(attendance)
    db.commit()
