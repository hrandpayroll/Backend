from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models.performance_reviews import PerformanceReview
from app.schemas.performance_reviews import PerformanceCreate, PerformanceUpdate, PerformanceResponse


router = APIRouter(prefix="/performance-reviews", 
                   tags=["Performance Reviews"])


@router.post("/", response_model=PerformanceResponse, status_code=status.HTTP_201_CREATED)
def create_review(review: PerformanceCreate, db: Session = Depends(get_db)):
    new_review = PerformanceReview(**review.model_dump())
    db.add(new_review)
    db.commit()
    db.refresh(new_review)
    return new_review



@router.get("/", response_model=List[PerformanceResponse])
def get_all_reviews(db: Session = Depends(get_db)):
    return db.query(PerformanceReview).all()


@router.get("/{review_id}", response_model=PerformanceResponse)
def get_review(review_id: int, db: Session = Depends(get_db)):
    review = db.query(PerformanceReview).filter(PerformanceReview.review_id == review_id).first()
    if not review:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Review not found")
    return review



@router.patch("/{review_id}", response_model=PerformanceResponse)
def update_review(review_id: int, updated: PerformanceUpdate, db: Session = Depends(get_db)):
    review = db.query(PerformanceReview).filter(PerformanceReview.review_id == review_id).first()
    if not review:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Review not found")

    updates = updated.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="No input fields received")
    for key, value in updates.items():
        setattr(review, key, value)

    db.commit()
    db.refresh(review)
    return review



@router.delete("/{review_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_review(review_id: int, db: Session = Depends(get_db)):
    review = db.query(PerformanceReview).filter(PerformanceReview.review_id == review_id).first()
    if not review:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Review not found")
    db.delete(review)
    db.commit()
