from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.models.expenses import Expenses
from app.schemas.expenses import ExpenseCreate, ExpenseUpdate, ExpenseResponse

router = APIRouter(prefix="/expenses",
                   tags=["Expenses"])


@router.post("/", response_model=ExpenseResponse, status_code=status.HTTP_201_CREATED)
def create_expense(expense: ExpenseCreate, db: Session = Depends(get_db)):
    new_expense = Expenses(**expense.model_dump())
    db.add(new_expense)
    db.commit()
    db.refresh(new_expense)
    return new_expense



@router.get("/", response_model=List[ExpenseResponse])
def list_expenses(db: Session = Depends(get_db)):
    return db.query(Expenses).all()



@router.get("/{expense_id}", response_model=ExpenseResponse)
def get_expense(expense_id: int, db: Session = Depends(get_db)):
    expense = db.query(Expenses).filter(Expenses.expense_id == expense_id).first()
    if not expense:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail="Expense not found")
    return expense



@router.patch("/{expense_id}", response_model=ExpenseResponse)
def update_expense(expense_id: int, update: ExpenseUpdate, db: Session = Depends(get_db)):
    expense = db.query(Expenses).filter(Expenses.expense_id == expense_id).first()
    if not expense:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail="Expense not found")

    updates = update.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="No fields to update")

    for key, value in updates.items():
        setattr(expense, key, value)

    db.commit()
    db.refresh(expense)
    return expense



@router.delete("/{expense_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_expense(expense_id: int, db: Session = Depends(get_db)):
    expense = db.query(Expenses).filter(Expenses.expense_id == expense_id).first()
    if not expense:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Expense not found")

    db.delete(expense)
    db.commit()
    return None
