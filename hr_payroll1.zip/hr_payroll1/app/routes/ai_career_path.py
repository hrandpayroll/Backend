from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.ai_career_path import AICareerPath
from app.schemas.ai_career_path import AICareerPathCreate, AICareerPathOut, AICareerPathUpdate

router = APIRouter(
    prefix="/career-paths",
    tags=["AI Career Path"]
)



@router.post("/", response_model=AICareerPathOut, status_code=status.HTTP_201_CREATED)
def create_career_path(payload: AICareerPathCreate, db: Session = Depends(get_db)):
    new_entry = AICareerPath(**payload.model_dump())
    db.add(new_entry)
    db.commit()
    db.refresh(new_entry)
    return new_entry



@router.get("/", response_model=List[AICareerPathOut])
def get_all_career_paths(db: Session = Depends(get_db)):
    return db.query(AICareerPath).all()



@router.get("/{career_id}", response_model=AICareerPathOut)
def get_career_path(career_id: int, db: Session = Depends(get_db)):
    career = db.query(AICareerPath).filter(AICareerPath.id == career_id).first()
    if not career:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail="Career path not found")
    return career



@router.put("/{career_id}", response_model=AICareerPathOut)
def update_career_path(career_id: int, payload: AICareerPathUpdate, db: Session = Depends(get_db)):
    career = db.query(AICareerPath).filter(AICareerPath.id == career_id).first()
    if not career:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail="Career path not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(career, key, value)
    db.commit()
    db.refresh(career)
    return career



@router.delete("/{career_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_career_path(career_id: int, db: Session = Depends(get_db)):
    career = db.query(AICareerPath).filter(AICareerPath.id == career_id).first()
    if not career:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail="Career path not found")
    db.delete(career)
    db.commit()

