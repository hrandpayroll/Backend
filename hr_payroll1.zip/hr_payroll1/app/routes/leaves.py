from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.models.leaves import Leaves
from app.schemas.leaves import LeaveCreate, LeaveUpdate, LeaveResponse

router = APIRouter(prefix="/leaves", tags=["Leaves"])


@router.post("/", response_model=LeaveResponse, status_code=status.HTTP_201_CREATED)
def apply_leave(leave: LeaveCreate, db: Session = Depends(get_db)):
    new_leave = Leaves(**leave.model_dump()) 
    db.add(new_leave)
    db.commit()
    db.refresh(new_leave)
    return new_leave



@router.get("/", response_model=List[LeaveResponse])
def list_leaves(db: Session = Depends(get_db)):
    return db.query(Leaves).all()



@router.get("/{leave_id}", response_model=LeaveResponse)
def get_leave(leave_id: int, db: Session = Depends(get_db)):
    leave = db.query(Leaves).filter(Leaves.leave_id == leave_id).first()
    if not leave:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Leave not found")
    return leave



@router.patch("/{leave_id}", response_model=LeaveResponse)
def update_leave(leave_id: int, update: LeaveUpdate, db: Session = Depends(get_db)):
    leave = db.query(Leaves).filter(Leaves.leave_id == leave_id).first()
    if not leave:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail="Leave not found")
    
    updates = update.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="No fields to update")
    
    for key, value in updates.items():
        setattr(leave, key, value)

    db.commit()
    db.refresh(leave)
    return leave



@router.delete("/{leave_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_leave(leave_id: int, db: Session = Depends(get_db)):
    leave = db.query(Leaves).filter(Leaves.leave_id == leave_id).first()
    if not leave:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Leave not found")
    db.delete(leave)
    db.commit()
