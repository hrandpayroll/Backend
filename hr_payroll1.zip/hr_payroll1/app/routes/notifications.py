from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.notifications import Notification
from app.schemas.notifications import NotificationCreate, NotificationOut, NotificationUpdate

router = APIRouter(
    prefix="/notifications",
    tags=["Notifications"]
)



@router.post("/", response_model=NotificationOut, status_code=status.HTTP_201_CREATED)
def create_notification(payload: NotificationCreate, db: Session = Depends(get_db)):
    notif = Notification(**payload.dict())
    db.add(notif)
    db.commit()
    db.refresh(notif)
    return notif



@router.get("/", response_model=list[NotificationOut], status_code=status.HTTP_200_OK)
def get_all_notifications(db: Session = Depends(get_db)):
    return db.query(Notification).all()



@router.get("/employee/{employee_id}", response_model=list[NotificationOut], status_code=status.HTTP_200_OK)
def get_employee_notifications(employee_id: int, db: Session = Depends(get_db)):
    return db.query(Notification).filter(Notification.employee_id == employee_id).all()



@router.put("/{notif_id}", response_model=NotificationOut, status_code=status.HTTP_200_OK)
def update_notification(notif_id: int, payload: NotificationUpdate, db: Session = Depends(get_db)):
    notif = db.query(Notification).filter(Notification.notif_id == notif_id).first()
    if not notif:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Notification not found")
    notif.is_read = payload.is_read
    db.commit()
    db.refresh(notif)
    return notif



@router.delete("/{notif_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_notification(notif_id: int, db: Session = Depends(get_db)):
    notif = db.query(Notification).filter(Notification.notif_id == notif_id).first()
    if not notif:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Notification not found")
    db.delete(notif)
    db.commit()
    return
