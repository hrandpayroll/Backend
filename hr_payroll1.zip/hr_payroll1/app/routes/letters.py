from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.letters import Letter
from app.schemas.letters import LetterCreate, LetterUpdate, LetterOut

router = APIRouter(prefix="/letters", tags=["Letters"])

@router.post("/", response_model=LetterOut, status_code=status.HTTP_201_CREATED)
def create_letter(payload: LetterCreate, db: Session = Depends(get_db)):
    letter = Letter(**payload.model_dump())
    db.add(letter)
    db.commit()
    db.refresh(letter)
    return letter

@router.get("/{letter_id}", response_model=LetterOut)
def get_letter(letter_id: int, db: Session = Depends(get_db)):
    letter = db.query(Letter).filter(Letter.letter_id == letter_id).first()
    if not letter:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Letter not found")
    return letter

@router.get("/", response_model=list[LetterOut])
def get_all_letters(db: Session = Depends(get_db)):
    return db.query(Letter).all()

@router.put("/{letter_id}", response_model=LetterOut)
def update_letter(letter_id: int, payload: LetterUpdate, db: Session = Depends(get_db)):
    letter = db.query(Letter).filter(Letter.letter_id == letter_id).first()
    if not letter:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Letter not found")
    
    for key, value in payload.dict(exclude_unset=True).items():
        setattr(letter, key, value)
    
    db.commit()
    db.refresh(letter)
    return letter

@router.delete("/{letter_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_letter(letter_id: int, db: Session = Depends(get_db)):
    letter = db.query(Letter).filter(Letter.letter_id == letter_id).first()
    if not letter:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Letter not found")
    
    db.delete(letter)
    db.commit()
