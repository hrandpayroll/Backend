from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from app.database import get_db
from sqlalchemy.orm import Session
from app.models.payroll import Payroll
from app.schemas.payroll import PayrollCreate, PayrollOut, PayrollUpdate

router = APIRouter(prefix="/payroll",
                   tags=["Payroll"])



@router.post("/", status_code=status.HTTP_201_CREATED, response_model=PayrollOut)
def create_payroll(payroll: PayrollCreate, db: Session = Depends(get_db)):
    new_payroll = Payroll(**payroll.model_dump())
    db.add(new_payroll)
    db.commit()
    db.refresh(new_payroll)
    return new_payroll



@router.get("/", response_model=List[PayrollOut])
def get_all_payrolls(db: Session = Depends(get_db)):
    return db.query(Payroll).all()



@router.get("/{payroll_id}", response_model=PayrollOut)
def get_payroll(payroll_id: int, db: Session = Depends(get_db)):
    payroll = db.query(Payroll).filter(Payroll.payroll_id == payroll_id).first()
    if not payroll:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail="Payroll record not found")
    return payroll




@router.patch("/{payroll_id}", response_model=PayrollOut)
def update_payroll(payroll_id: int, updated: PayrollUpdate, db: Session = Depends(get_db)):
    payroll = db.query(Payroll).filter(Payroll.payroll_id == payroll_id).first()
    if not payroll:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail="Payroll record not found")
    updates = updated.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, 
                            detail="No input fields received")
    for key, value in updates.items():
        setattr(payroll, key, value)
    db.commit()
    db.refresh(payroll)
    return payroll



@router.delete("/{payroll_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_payroll(payroll_id: int, db: Session = Depends(get_db)):
    payroll = db.query(Payroll).filter(Payroll.payroll_id == payroll_id).first()
    if not payroll:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                            detail="Payroll record not found")
    db.delete(payroll)
    db.commit()
    