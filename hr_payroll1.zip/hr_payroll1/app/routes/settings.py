from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.settings import Setting
from app.schemas.settings import SettingCreate, SettingUpdate, SettingOut

router = APIRouter(prefix="/settings", tags=["Settings"])

@router.post("/", response_model=SettingOut, status_code=status.HTTP_201_CREATED)
def create_setting(payload: SettingCreate, db: Session = Depends(get_db)):
    new_setting = Setting(**payload.dict())
    db.add(new_setting)
    db.commit()
    db.refresh(new_setting)
    return new_setting

@router.get("/{setting_id}", response_model=SettingOut)
def get_setting(setting_id: int, db: Session = Depends(get_db)):
    setting = db.query(Setting).filter(Setting.setting_id == setting_id).first()
    if not setting:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Setting not found")
    return setting

@router.get("/", response_model=list[SettingOut])
def get_all_settings(db: Session = Depends(get_db)):
    return db.query(Setting).all()

@router.put("/{setting_id}", response_model=SettingOut)
def update_setting(setting_id: int, payload: SettingUpdate, db: Session = Depends(get_db)):
    setting = db.query(Setting).filter(Setting.setting_id == setting_id).first()
    if not setting:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Setting not found")
    for key, value in payload.dict(exclude_unset=True).items():
        setattr(setting, key, value)
    db.commit()
    db.refresh(setting)
    return setting

@router.delete("/{setting_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_setting(setting_id: int, db: Session = Depends(get_db)):
    setting = db.query(Setting).filter(Setting.setting_id == setting_id).first()
    if not setting:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Setting not found")
    db.delete(setting)
    db.commit()
