from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models.ai_mood_index import AIMoodIndex
from app.schemas.ai_mood_index import AIMoodCreate, AIMoodUpdate, AIMoodResponse

router = APIRouter(prefix="/mood", 
                   tags=["AI Mood Index"])


@router.post("/", response_model=AIMoodResponse, status_code=status.HTTP_201_CREATED)
def create_mood_record(record: AIMoodCreate, db: Session = Depends(get_db)):
    mood = AIMoodIndex(**record.model_dump())
    db.add(mood)
    db.commit()
    db.refresh(mood)
    return mood



@router.get("/", response_model=List[AIMoodResponse])
def list_all_moods(db: Session = Depends(get_db)):
    return db.query(AIMoodIndex).all()



@router.get("/{id}", response_model=AIMoodResponse)
def get_mood_by_id(id: int, db: Session = Depends(get_db)):
    mood = db.query(AIMoodIndex).filter(AIMoodIndex.id == id).first()
    if not mood:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Mood record not found"
        )
    return mood


@router.patch("/{id}", response_model=AIMoodResponse)
def update_mood(id: int, updates: AIMoodUpdate, db: Session = Depends(get_db)):
    mood = db.query(AIMoodIndex).filter(AIMoodIndex.id == id).first()
    if not mood:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Mood record not found"
        )

    updates = updates.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="No input fields received")
         
    for key, value in updates.items():
        setattr(mood, key, value)

    db.commit()
    db.refresh(mood)
    return mood



@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_mood(id: int, db: Session = Depends(get_db)):
    mood = db.query(AIMoodIndex).filter(AIMoodIndex.id == id).first()
    if not mood:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Mood record not found"
        )

    db.delete(mood)
    db.commit()
    