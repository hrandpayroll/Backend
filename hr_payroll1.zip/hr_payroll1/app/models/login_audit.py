from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, TIMESTAMP
from sqlalchemy.orm import relationship
from app.database import Base

class LoginAudit(Base):
    __tablename__ = "login_audit"

    audit_id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.user_id"), nullable=False)
    timestamp = Column(TIMESTAMP, nullable=False)
    ip_address = Column(String(45), nullable=True)
    device_type = Column(String(100), nullable=True)
    success = Column(Boolean, nullable=False)

    user = relationship("User")
