from sqlalchemy import Column, Integer, Date, ForeignKey, Text, Boolean, CheckConstraint
from sqlalchemy.orm import relationship
from app.database import Base

class PerformanceReview(Base):
    __tablename__ = "performance_reviews"

    review_id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=False)
    reviewer_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=False)
    review_period = Column(Date, nullable=False)
    rating = Column(Integer, nullable=False)
    strengths = Column(Text, nullable=False)
    areas_of_improvement = Column(Text, nullable=False)
    promotion_recommendation = Column(Boolean, nullable=False)

    employee = relationship("Employee",foreign_keys=[employee_id])
    reviewer = relationship("Employee",foreign_keys=[reviewer_id])

    __table_args__ = (
        CheckConstraint('rating BETWEEN 1 AND 5', name='rating_range_check'),
    )
