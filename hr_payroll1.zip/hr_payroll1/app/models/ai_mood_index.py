from sqlalchemy import Column, Integer, Float, TIMESTAMP, ForeignKey, text
from sqlalchemy.orm import relationship
from sqlalchemy import Enum as SQLEnum
from enum import Enum as PyEnum
from app.database import Base

class MoodSource(PyEnum):
    CHAT = "chat"
    EMAIL = "email"
    SURVEY = "survey"

class AIMoodIndex(Base):
    __tablename__ = "ai_mood_index"

    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=False)
    mood_score = Column(Float, nullable=False)
    recorded_on = Column(TIMESTAMP(timezone=True), server_default=text('now()'), nullable=False)
    source = Column(SQLEnum(
        MoodSource,
        name="mood_source_enum",
        values_callable=lambda enum: [e.value for e in enum],
        native_enum=True,
        create_type=False 
    ), nullable=False)

    employee = relationship("Employee")
