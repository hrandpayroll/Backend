from sqlalchemy import Column, Integer, Float, ForeignKey, TIMESTAMP
from sqlalchemy.orm import relationship
from app.database import Base

class AiRetentionRisk(Base):
    __tablename__ = "ai_retention_risk"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=False)
    risk_score = Column(Float, nullable=True)
    evaluated_on = Column(TIMESTAMP, nullable=True)

    employee = relationship("Employee")
