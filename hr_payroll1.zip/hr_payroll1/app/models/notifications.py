from sqlalchemy import Column, Integer, ForeignKey, Text, Boolean, TIMESTAMP, func
from sqlalchemy.orm import relationship
from app.database import Base 

class Notification(Base):
    __tablename__ = "notifications"

    notif_id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id", ondelete="CASCADE"), nullable=False)
    message = Column(Text, nullable=False)
    created_at = Column(TIMESTAMP, server_default=func.now())
    is_read = Column(Boolean, default=False)

    employee = relationship("Employee")
