from sqlalchemy import Column, Integer, String, Numeric, Date, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base
from enum import Enum as PyEnum
from sqlalchemy import Enum as SQLEnum

class ExpensesStatus(PyEnum):
    APPROVED = 'Approved'
    REJECTED = 'Rejected'
    PENDING = 'Pending'

class Expenses(Base):
    __tablename__ = "expenses"

    expense_id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=False)
    category = Column(String(255), nullable=False)
    amount = Column(Numeric, nullable=False)
    date_submitted = Column(Date, nullable=False)
    status = Column(SQLEnum(
        ExpensesStatus,
        name = "expenses_status_enum",
        values_callable = lambda e: [member.value for member in e],
        native_enum = True,
        create_type = False
    ), nullable=False)
    receipt_link = Column(String, nullable=False)

    employee = relationship("Employee")