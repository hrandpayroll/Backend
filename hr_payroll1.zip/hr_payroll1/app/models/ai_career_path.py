from sqlalchemy import Column, Integer, String, Text, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base  

class AICareerPath(Base):
    __tablename__ = "ai_career_path"

    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id", ondelete="CASCADE"), nullable=False)
    recommended_role = Column(String(255),nullable=False)
    suggested_courses = Column(Text,nullable=False)
    predicted_growth_years = Column(Integer,nullable=False)

    employee = relationship("Employee")
