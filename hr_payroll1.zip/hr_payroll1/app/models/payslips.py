from sqlalchemy import TIMESTAMP, Column, Date, ForeignKey, Integer, String, null, text
from app.database import Base
from sqlalchemy.orm import relationship


class PaySlips(Base):
    __tablename__ = "payslips"

    payslip_id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=False)
    month = Column(Date, nullable=False)
    generated_on = Column(TIMESTAMP(timezone=True), nullable=False, server_default=text('now()'))
    blockchain_hash = Column(String(255), nullable=False)
    pdf_link = Column(String(255), nullable=False)

    employee = relationship("Employee")