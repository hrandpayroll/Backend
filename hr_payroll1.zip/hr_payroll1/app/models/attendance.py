from sqlalchemy import Column, Date, Integer, DateTime, ForeignKey,String,Boolean, text
from app.database import Base
from sqlalchemy.orm import relationship

class Attendance(Base):
    __tablename__ = "attendance"

    attendance_id=Column(Integer,primary_key=True)
    employee_id = Column(Integer,ForeignKey("employees.employee_id") ,nullable=False)
    attendance_date = Column(Date, nullable=False, server_default=text("CURRENT_DATE"))
    clock_in = Column(DateTime(timezone=True),server_default=text('now()'), nullable=False)
    clock_out = Column(DateTime(timezone=True), nullable=False)
    location=Column(String(255), nullable=False)
    face_id_verified=Column(Boolean,default=False,nullable=False)

    employee = relationship("Employee")