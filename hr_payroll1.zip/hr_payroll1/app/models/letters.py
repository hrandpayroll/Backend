from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, TIMESTAMP, CheckConstraint
from sqlalchemy.orm import relationship
from app.database import Base
from sqlalchemy import Enum as SQLEnum
from enum import Enum as PyEnum

class LetterType(PyEnum):
    OFFER = "Offer"
    EXIT = "Exit"
    INCREMENT = "Increment"



class Letter(Base):
    __tablename__ = "letters"

    letter_id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=False)
    letter_type = Column(SQLEnum(
        LetterType,
        name='letter_type_enum',
        values_callable = lambda e : [member.value for member in e],
        create_type = False,
        native_enum = True
    ), nullable=False)
    generated_on = Column(TIMESTAMP, nullable=True)
    signed = Column(Boolean, default=False)
    doc_link = Column(String(255), nullable=True)

    employee = relationship("Employee")  
