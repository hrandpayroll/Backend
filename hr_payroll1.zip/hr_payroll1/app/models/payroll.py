from sqlalchemy import Column, Integer, String, Date, Numeric, ForeignKey
from app.database import Base
from enum import Enum as PyEnum
from sqlalchemy import Enum as SQLEnum
from sqlalchemy.orm import relationship


class PayrollStatus(PyEnum):
    PAID = 'Paid'
    UNPAID = 'Unpaid'

class Payroll(Base):
    __tablename__ = "payroll"

    payroll_id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=False)
    month = Column(Date, nullable=False)
    base_salary = Column(Numeric, nullable=False)
    bonus = Column(Numeric, nullable=False)
    tax_deducted = Column(Numeric, nullable=False)
    net_payable = Column(Numeric, nullable=False)
    status = Column(SQLEnum(
        PayrollStatus,
        name="payroll_status_enum",
        values_callable=lambda e: [member.value for member in e],
        native_enum=True,
        create_type=False
    ), nullable=False)

    employee_details = relationship("Employee")