from sqlalchemy import Column, Date, ForeignKey, Integer
from app.database import Base
from sqlalchemy import Enum as SQLEnum
from enum import Enum as PyEnum
from sqlalchemy.orm import relationship

class LeaveType(PyEnum):
    CASUAL = 'Casual'
    EARNED = 'Earned'
    SICK = 'Sick'

class LeaveStatus(PyEnum):
    APPROVED = 'Approved'
    REJECTED = 'Rejected'
    PENDING = 'Pending'

class Leaves(Base):
    __tablename__ = "leaves"

    leave_id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    status = Column(SQLEnum(
        LeaveStatus,
        name="leave_status_enum",
        values_callable = lambda e: [member.value for member in e ],
        create_type = False,
        native_enum = True
    ),nullable=False)
    leave_type = Column(SQLEnum(
        LeaveType,
        name = "leave_type_enum",
        values_callable = lambda e:[member.value for member in e],
        native_enum=True,
        create_type = False
    ),nullable=False)


    employee = relationship("Employee")