from sqlalchemy import Column, Integer, String, Text
from app.database import Base

class Setting(Base):
    __tablename__ = "settings"

    setting_id = Column(Integer, primary_key=True)
    setting_key = Column(String(255), nullable=False)
    value = Column(Text, nullable=True)
    module_name = Column(String(100), nullable=True)
