from fastapi import FastAPI
from app.database import Base, engine 
from app import models
from app.routes import (department, job_role, employee, ai_retention_risk,
                        payroll, payslips, attendance, login_audit,
                        leaves, expenses, performance_reviews, 
                        ai_mood_index, notifications, settings,
                        letters, roles, users, login, ai_career_path)

Base.metadata.create_all(bind=engine)

app = FastAPI()

@app.get('/')
def root():
    return { 'Welcome to the API!!!' }

app.include_router(login.router)
app.include_router(department.router)
app.include_router(job_role.router)
app.include_router(employee.router)
app.include_router(payroll.router)
app.include_router(payslips.router)
app.include_router(attendance.router)
app.include_router(leaves.router)
app.include_router(expenses.router)
app.include_router(performance_reviews.router)
app.include_router(ai_mood_index.router)
app.include_router(roles.router)
app.include_router(users.router)
app.include_router(ai_career_path.router)
app.include_router(notifications.router)
app.include_router(settings.router)
app.include_router(letters.router)
app.include_router(login_audit.router)
app.include_router(ai_retention_risk.router)