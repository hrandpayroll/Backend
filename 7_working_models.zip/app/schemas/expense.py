from pydantic import BaseModel
from typing import Optional
from datetime import date

class ExpenseBase(BaseModel):
    employee_id: int
    category: str
    amount: float
    date_submitted: date
    status: str
    receipt_link: Optional[str] = None

class ExpenseCreate(ExpenseBase):
    pass

class ExpenseRead(ExpenseBase):
    expense_id: int

    class Config:
        orm_mode = True

class ExpenseUpdate(BaseModel):
    category: Optional[str] = None
    amount: Optional[float] = None
    date_submitted: Optional[date] = None
    status: Optional[str] = None
    receipt_link: Optional[str] = None
