from fastapi import FastAPI
from app.database import Base, engine
from app.routes import ai_career_path, ai_mood_index

app = FastAPI(title="AI Tools API", version="1.0")


Base.metadata.create_all(bind=engine)

@app.get("/")
def welcome():
    return {"message": "Welcome to the AI Tools API"}


app.include_router(ai_career_path.router)
app.include_router(ai_mood_index.router)
