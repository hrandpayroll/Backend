from sqlalchemy import Column,String,ForeignKey,Float,DateTime,Integer
from app.database import Base
from sqlalchemy.sql import func

class AIMoodIndex(Base):
    __tablename__="ai_mood_index"
    id=Column(Integer,primary_key=True,index=True)
    employee_id=Column(Integer,ForeignKey("employees.employee_id"),nullable=False)
    mood_score=Column(Float,nullable=False)
    recorded_on=Column(DateTime(timezone=True),server_default=func.now())
    source=Column(String,nullable=False)
    