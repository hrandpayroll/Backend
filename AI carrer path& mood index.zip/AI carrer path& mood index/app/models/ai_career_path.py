from sqlalchemy import Column,String,Integer,ForeignKey
from app.database import Base


class AICareerPath(Base):
    __tablename__="ai_career_path"
    id=Column(Integer,primary_key=True,index=True)
    employee_id=Column(Integer,ForeignKey("employees.employee_id"),nullable=False)
    recommended_role=Column(String(100),nullable=False)
    suggested_course=Column(String(100),nullable=False)
    predicted_growth_years=Column(Integer,nullable=False)
    