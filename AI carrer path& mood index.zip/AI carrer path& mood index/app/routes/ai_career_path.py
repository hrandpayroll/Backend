from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.ai_career_path  import AICareerPath
from app.schemas.ai_career_path import AICareerPathCreate,AICareerPathResponse

router=APIRouter(prefix="/carrer-path",tags=["AI Carrer Path"])


@router.post("/", response_model=AICareerPathResponse)                       
def create_carrer_path(data:AICareerPathCreate,db:Session=Depends(get_db)):                        
    record=AICareerPath(**data.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return record



@router.get("/{employee_id}",response_model=list[AICareerPathResponse])
def get_paths_for_employee(employee_id:int,db:Session=Depends(get_db)):
   records=db.query(AICareerPath).filter(AICareerPath.employee_id==employee_id).all()
   return records
    
