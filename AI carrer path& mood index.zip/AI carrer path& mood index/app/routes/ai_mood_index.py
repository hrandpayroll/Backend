from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.ai_mood_index import AIMoodIndex
from app.schemas.ai_mood_index import AIMoodIndexCreate, AIMoodIndexResponse

router = APIRouter(prefix="/mood-index", tags=["AI Mood Index"])

@router.post("/", response_model=AIMoodIndexResponse)
def create_mood_index(data: AIMoodIndexCreate, db: Session = Depends(get_db)):
    record = AIMoodIndex(**data.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return record

@router.get("/{employee_id}", response_model=list[AIMoodIndexResponse])
def get_moods_for_employee(employee_id: int, db: Session = Depends(get_db)):
    records = db.query(AIMoodIndex).filter(AIMoodIndex.employee_id == employee_id).all()
    return records
