from pydantic import BaseModel
from datetime import datetime


class AIMoodIndexBase(BaseModel):
    employee_id:int
    mood_score:float
    source:str

class AIMoodIndexCreate(AIMoodIndexBase):
    pass


class AIMoodIndexResponse(AIMoodIndexBase):
    id:int
    recorded_on:datetime


    class Config:
        from_attributes=True