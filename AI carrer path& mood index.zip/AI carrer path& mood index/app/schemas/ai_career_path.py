from pydantic import BaseModel

class AICareerPathBase(BaseModel):
    employee_id:int
    recommended_role:str
    suggested_course:str
    predicted_growth_years:int


class AICareerPathCreate(AICareerPathBase):
    pass


class AICareerPathResponse(AICareerPathBase):
    id:int


    class Config:
        from_attributes=True

    

    