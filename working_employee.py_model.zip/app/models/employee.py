from sqlalchemy import Column, Integer, String, Date, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.database import Base
from enum import Enum as PyEnum
from sqlalchemy import Enum
from sqlalchemy import Enum as SQLEnum

class EmployeeStatus(PyEnum):
    ACTIVE = "Active"
    ON_LEAVE = "On Leave"
    RESIGNED = "Resigned"

class Employee(Base):
    __tablename__ = "employees"

    employee_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    first_name = Column(String(255),nullable=False)
    last_name = Column(String(255),nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    phone_number = Column(String(255))
    department_id = Column(Integer, ForeignKey("departments.department_id"))
    job_role_id = Column(Integer, ForeignKey("job_roles.job_role_id"))
    date_of_joining = Column(Date)
    status = Column(
    SQLEnum(
        EmployeeStatus,
        name="employee_status_enum",
        values_callable=lambda enum: [e.value for e in enum],
        native_enum=True,
        create_type=False
    ),
    nullable=True
)
    manager_id = Column(Integer, ForeignKey("employees.employee_id"))
    aadhaar_number = Column(String(255))
    bank_account_number = Column(String(255))
    pan_number = Column(String(255))
    profile_picture = Column(Text)

    # Optional: set up relationships (if needed)
    department = relationship("Department", back_populates="employees")
    job_role = relationship("JobRole", back_populates="employees")
    manager = relationship("Employee", remote_side=[employee_id], backref="subordinates")

