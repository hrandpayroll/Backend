from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.settings import Settings
from app.schemas.settings import SettingCreate, SettingUpdate, SettingResponse

router = APIRouter(prefix="/settings", tags=["Settings"])


@router.post("/", response_model=SettingResponse)
def create_setting(data: SettingCreate, db: Session = Depends(get_db)):
    if db.query(Settings).filter(Settings.key == data.key).first():
        raise HTTPException(status_code=400, detail="Setting key already exists")
    record = Settings(**data.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.get("/", response_model=list[SettingResponse])
def get_all_settings(db: Session = Depends(get_db)):
    return db.query(Settings).all()


@router.get("/{key}", response_model=SettingResponse)
def get_setting_by_key(key: str, db: Session = Depends(get_db)):
    setting = db.query(Settings).filter(Settings.key == key).first()
    if not setting:
        raise HTTPException(status_code=404, detail="Setting not found")
    return setting


@router.put("/{key}", response_model=SettingResponse)
def update_setting(key: str, data: SettingUpdate, db: Session = Depends(get_db)):
    setting = db.query(Settings).filter(Settings.key == key).first()
    if not setting:
        raise HTTPException(status_code=404, detail="Setting not found")
    setting.value = data.value
    db.commit()
    db.refresh(setting)
    return setting


@router.delete("/{key}")
def delete_setting(key: str, db: Session = Depends(get_db)):
    setting = db.query(Settings).filter(Settings.key == key).first()
    if not setting:
        raise HTTPException(status_code=404, detail="Setting not found")
    db.delete(setting)
    db.commit()
    return {"message": f"Setting '{key}' deleted successfully."}


