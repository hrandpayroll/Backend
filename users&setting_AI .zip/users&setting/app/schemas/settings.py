from pydantic import BaseModel

class SettingCreate(BaseModel):
    key: str
    value: str

class SettingUpdate(BaseModel):
    value: str

class SettingResponse(SettingCreate):
    id: int

    class Config:
        from_attributes = True




