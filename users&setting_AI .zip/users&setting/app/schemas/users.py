from pydantic import BaseModel, EmailStr

class UserCreate(BaseModel):
    email: EmailStr
    encrypted_password: str
    role_id: int

class UserUpdate(BaseModel):
    email: EmailStr
    encrypted_password: str
    role_id: int

class UserResponse(UserCreate):
    user_id: int

    class Config:
        from_attributes = True
