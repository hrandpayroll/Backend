from pydantic import BaseModel
from datetime import datetime

class AICareerPathCreate(BaseModel):
    employee_id: int
    current_role: str
    target_role: str
    suggested_skills: str

class AICareerPathUpdate(BaseModel):
    current_role: str
    target_role: str
    suggested_skills: str

class AICareerPathResponse(AICareerPathCreate):
    id: int
    created_on: datetime

    class Config:
        from_attributes = True


    

    