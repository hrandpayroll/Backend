from pydantic import BaseModel
from datetime import datetime

class AIMoodIndexCreate(BaseModel):
    employee_id: int
    mood_score: float
    mood_label: str

class AIMoodIndexUpdate(BaseModel):
    mood_score: float
    mood_label: str

class AIMoodIndexResponse(AIMoodIndexCreate):
    id: int
    timestamp: datetime

    class Config:
        from_attributes = True
