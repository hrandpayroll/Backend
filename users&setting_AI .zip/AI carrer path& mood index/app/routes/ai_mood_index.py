from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.ai_mood_index import AIMoodIndex
from app.schemas.ai_mood_index import AIMoodIndexCreate, AIMoodIndexUpdate, AIMoodIndexResponse

router = APIRouter(prefix="/mood-index", tags=["AI Mood Index"])


@router.post("/", response_model=AIMoodIndexResponse)
def create_mood_index(data: AIMoodIndexCreate, db: Session = Depends(get_db)):
    record = AIMoodIndex(**data.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.get("/employee/{employee_id}", response_model=list[AIMoodIndexResponse])
def get_moods_for_employee(employee_id: int, db: Session = Depends(get_db)):
    return db.query(AIMoodIndex).filter(AIMoodIndex.employee_id == employee_id).all()


@router.get("/{id}", response_model=AIMoodIndexResponse)
def get_mood_by_id(id: int, db: Session = Depends(get_db)):
    mood = db.query(AIMoodIndex).filter(AIMoodIndex.id == id).first()
    if not mood:
        raise HTTPException(status_code=404, detail="Mood entry not found")
    return mood


@router.put("/{id}", response_model=AIMoodIndexResponse)
def update_mood(id: int, data: AIMoodIndexUpdate, db: Session = Depends(get_db)):
    mood = db.query(AIMoodIndex).filter(AIMoodIndex.id == id).first()
    if not mood:
        raise HTTPException(status_code=404, detail="Mood entry not found")
    for key, value in data.model_dump().items():
        setattr(mood, key, value)
    db.commit()
    db.refresh(mood)
    return mood


@router.delete("/{id}")
def delete_mood(id: int, db: Session = Depends(get_db)):
    mood = db.query(AIMoodIndex).filter(AIMoodIndex.id == id).first()
    if not mood:
        raise HTTPException(status_code=404, detail="Mood entry not found")
    db.delete(mood)
    db.commit()
    return {"message": f"Mood record {id} deleted successfully."}

