from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.ai_career_path import AICareerPath
from app.schemas.ai_career_path import AICareerPathCreate, AICareerPathResponse, AICareerPathUpdate

router = APIRouter(prefix="/career-path", tags=["AI Career Path"])


@router.post("/", response_model=AICareerPathResponse)
def create_path(data: AICareerPathCreate, db: Session = Depends(get_db)):
    record = AICareerPath(**data.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return record

@router.get("/employee/{employee_id}", response_model=list[AICareerPathResponse])
def get_paths(employee_id: int, db: Session = Depends(get_db)):
    records = db.query(AICareerPath).filter(AICareerPath.employee_id == employee_id).all()
    return records


@router.get("/{id}", response_model=AICareerPathResponse)
def get_path(id: int, db: Session = Depends(get_db)):
    path = db.query(AICareerPath).filter(AICareerPath.id == id).first()
    if not path:
        raise HTTPException(status_code=404, detail="Career path not found")
    return path


@router.put("/{id}", response_model=AICareerPathResponse)
def update_path(id: int, data: AICareerPathUpdate, db: Session = Depends(get_db)):
    path = db.query(AICareerPath).filter(AICareerPath.id == id).first()
    if not path:
        raise HTTPException(status_code=404, detail="Career path not found")
    for key, value in data.model_dump().items():
        setattr(path, key, value)
    db.commit()
    db.refresh(path)
    return path


@router.delete("/{id}")
def delete_path(id: int, db: Session = Depends(get_db)):
    path = db.query(AICareerPath).filter(AICareerPath.id == id).first()
    if not path:
        raise HTTPException(status_code=404, detail="Career path not found")
    db.delete(path)
    db.commit()
    return {"message": f"Career path {id} deleted successfully."}

    
