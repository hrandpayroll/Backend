from sqlalchemy import Column,String,Integer
from app.database import Base


class Settings(Base):
    __tablename__="settings"
    setting_id=Column(Integer,primary_key=True,index=True)
    setting_key=Column(String,nullable=False)
    value=Column(String,nullable=False)
    module_name=Column(String,nullable=False)



