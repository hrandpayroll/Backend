from sqlalchemy import Column,String,ForeignKey,Integer
from app.database import Base


class Users(Base):
    __tablename__="users"
    user_id=Column(Integer,primary_key=True,index=True)
    email=Column(String,nullable=False)
    encrypted_password=Column(String,nullable=False)
    role_id=Column(Integer,ForeignKey("roles.role_id"),nullable=False)



    