from fastapi import FastAPI
from app.database import Base, engine
from app.routes import settings,users

app = FastAPI()


Base.metadata.create_all(bind=engine)


@app.get("/")
def welcome():
    return {"message": "Welcome to the AI HR System 🚀"}


app.include_router(settings.router)
app.include_router(users.router)
