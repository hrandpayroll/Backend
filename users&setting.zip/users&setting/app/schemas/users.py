from pydantic import BaseModel,EmailStr


class UserBase(BaseModel):
    email:EmailStr
    encrypted_password:str
    role_id:int


class UserCreate(UserBase):
    pass


class UserResponse(UserBase):
    user_id:int


class Config:
    from_attributes=True


