from pydantic import BaseModel


class SettingBase(BaseModel):
    setting_key:str
    value:str
    module_name:str

class SettingCreate(SettingBase):
    pass



class SettingResponse(SettingBase):
    setting_id:int


class Config:
    from_attributes=True


