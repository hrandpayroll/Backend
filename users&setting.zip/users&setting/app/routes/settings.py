from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.settings import Settings
from app.schemas.settings import SettingCreate, SettingResponse

router = APIRouter(prefix="/settings", tags=["Settings"])

@router.post("/", response_model=SettingResponse)
def create_setting(data: SettingCreate, db: Session = Depends(get_db)):
    record = Settings(**data.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return record

@router.get("/", response_model=list[SettingResponse])
def get_all_settings(db: Session = Depends(get_db)):
    return db.query(Settings).all()
