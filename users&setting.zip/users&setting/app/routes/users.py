from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.users import Users
from app.schemas.users import UserCreate, UserResponse

router = APIRouter(prefix="/users", tags=["Users"])

@router.post("/", response_model=UserResponse)
def create_user(data: UserCreate, db: Session = Depends(get_db)):
    existing = db.query(Users).filter(Users.email == data.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already exists")
    
    record = Users(**data.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return record

@router.get("/{user_id}", response_model=UserResponse)
def get_user(user_id: int, db: Session = Depends(get_db)):
    record = db.query(Users).filter(Users.user_id == user_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="User not found")
    return record
