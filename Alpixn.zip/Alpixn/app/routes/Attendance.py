from fastapi import APIRouter, Depends,HTTPException
from sqlalchemy.orm import Session
from project.database import get_db
from app import models, schemas

router = APIRouter(prefix="/attendance", tags=["Attendance"])




@router.post("/", response_model=schemas.AttendanceOut)
def mark_attendance(record: schemas.AttendanceCreate, db: Session = Depends(get_db)):
    db_attendance = models.Attendance(**record.dict())
    db.add(db_attendance)
    db.commit()
    db.refresh(db_attendance)
    return db_attendance

@router.get("/", response_model=list[schemas.AttendanceOut])
def list_attendance(db: Session = Depends(get_db)):
    return db.query(models.Attendance).all()
