from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from project.database import get_db
from app import models, schemas
router = APIRouter(prefix="/leave", tags=["Leave"])
@router.post("/", response_model=schemas.LeaveOut)
def create_leave(leave: schemas.LeaveCreate, db: Session = Depends(get_db)):
    db_leave = models.Leave(**leave.dict())
    db.add(db_leave)
    db.commit()
    db.refresh(db_leave)
    return db_leave
@router.get("/", response_model=list[schemas.LeaveOut])
def get_leaves(db: Session = Depends(get_db)):
    return db.query(models.Leave).all()
