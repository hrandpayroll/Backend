from fastapi import FastAPI
from models import Attendance,Leave
from routes import Attendance
from routes import Leave
from database import Base,engine
from routes import Leave

App=FastAPI()

Base.metadata.create_all(bind=engine)

@App.get("/")
def welcome():
    return {"message": "Welcome to Alpixn HR API"}

# Include the employee API routes
App.include_router(Attendance.router)
App.include_router(Leave.router)

