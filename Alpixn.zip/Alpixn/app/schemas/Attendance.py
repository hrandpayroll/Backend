from pydantic import BaseModel
from datetime import datetime

class AttendanceBase(BaseModel):
    employee_id: int
    date: datetime
    clock_in: datetime
    clock_out: datetime
    location: str | None = None
    face_id_verified: bool = False

class AttendanceCreate(AttendanceBase):
    pass

class AttendanceOut(AttendanceBase):
    attendance_id: int  

    class Config:  
        from_attributes = True

    