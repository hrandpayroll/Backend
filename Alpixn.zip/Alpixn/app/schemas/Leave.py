from pydantic import BaseModel
from datetime import date

class LeaveBase(BaseModel):
    employee_id:int
    start_date:date
    end_date:date
    type:str


class LeaveCreate(LeaveBase):
    pass



class LeaveOut(LeaveBase):
    leave_id:int
    status:str


class Config:
   from_attributes=True    