from sqlalchemy import Column,Integer,String,DateTime,Boolean
from app.database import Base

class Attendance(Base):
  __tablename__="Attendance"

  attendance_id=Column(Integer,primary_key=True,index=True)
  employee_id=Column(Integer,nullable=False)
  date =Column(DateTime,nullable=False)
  clock_in=Column(DateTime,nullable=False)
  clock_out=Column(DateTime)
  location=Column(String)
  face_id_verified=Column(Boolean,default=False)
  