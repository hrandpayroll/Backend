from sqlalchemy import Column, Integer, String, Date,ForeignKey,VARCHAR
from project.database import Base

class Leave(Base):
    __tablename__ = "leaves"

    leave_id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    type=Column(String,nullable=False)
    status = Column(String, default="Pending")