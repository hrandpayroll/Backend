import sys
import os

# Add the parent directory of `app/` to sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import SessionLocal
from app.models.department import Department

from app.models.employee import EmployeeStatus

print("💡 SQLAlchemy sees these enum values:")
for member in EmployeeStatus:
    print(f"{member.name} = {member.value}")

def run_test():
    db = SessionLocal()
    department = db.query(Department).filter(Department.department_name == "Engineering").first()
    if department:
        print("Department Name:", department.department_name)
        print("Employees in this Department:")
        for emp in department.employees:
            print(f"- {emp.first_name} {emp.last_name}")
    else:
        print("No departments found")

if __name__ == "__main__":
    run_test()
