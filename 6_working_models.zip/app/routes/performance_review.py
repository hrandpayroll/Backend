from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models.performance_review import PerformanceReview
from app.schemas.performance_review import PerformanceReviewCreate, PerformanceReviewRead, PerformanceReviewUpdate
from app.deps import get_db

router = APIRouter(
    prefix="/performance_reviews",
    tags=["Performance Reviews"]
)

@router.post("/", response_model=PerformanceReviewRead)
def create_review(review: PerformanceReviewCreate, db: Session = Depends(get_db)):
    new_review = PerformanceReview(**review.dict())
    db.add(new_review)
    db.commit()
    db.refresh(new_review)
    return new_review

@router.get("/{review_id}", response_model=PerformanceReviewRead)
def get_review(review_id: int, db: Session = Depends(get_db)):
    review = db.query(PerformanceReview).filter(PerformanceReview.review_id == review_id).first()
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    return review

@router.get("/", response_model=list[PerformanceReviewRead])
def get_all_reviews(db: Session = Depends(get_db)):
    return db.query(PerformanceReview).all()

@router.patch("/{review_id}", response_model=PerformanceReviewRead)
def update_review(review_id: int, updated: PerformanceReviewUpdate, db: Session = Depends(get_db)):
    review = db.query(PerformanceReview).filter(PerformanceReview.review_id == review_id).first()
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")

    for key, value in updated.dict(exclude_unset=True).items():
        setattr(review, key, value)

    db.commit()
    db.refresh(review)
    return review

@router.delete("/{review_id}")
def delete_review(review_id: int, db: Session = Depends(get_db)):
    review = db.query(PerformanceReview).filter(PerformanceReview.review_id == review_id).first()
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    db.delete(review)
    db.commit()
    return {"detail": "Performance review deleted successfully"}
