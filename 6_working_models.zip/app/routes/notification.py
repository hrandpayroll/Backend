from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models.notification import Notification
from app.schemas.notification import NotificationCreate, NotificationRead, NotificationUpdate
from app.deps import get_db

router = APIRouter(
    prefix="/notifications",
    tags=["Notifications"]
)

@router.post("/", response_model=NotificationRead)
def create_notification(notif: NotificationCreate, db: Session = Depends(get_db)):
    new_notif = Notification(**notif.dict())
    db.add(new_notif)
    db.commit()
    db.refresh(new_notif)
    return new_notif

@router.get("/{notif_id}", response_model=NotificationRead)
def get_notification(notif_id: int, db: Session = Depends(get_db)):
    notif = db.query(Notification).filter(Notification.notif_id == notif_id).first()
    if not notif:
        raise HTTPException(status_code=404, detail="Notification not found")
    return notif

@router.get("/", response_model=list[NotificationRead])
def get_all_notifications(db: Session = Depends(get_db)):
    return db.query(Notification).all()

@router.patch("/{notif_id}", response_model=NotificationRead)
def update_notification(notif_id: int, updated: NotificationUpdate, db: Session = Depends(get_db)):
    notif = db.query(Notification).filter(Notification.notif_id == notif_id).first()
    if not notif:
        raise HTTPException(status_code=404, detail="Notification not found")
    for key, value in updated.dict(exclude_unset=True).items():
        setattr(notif, key, value)
    db.commit()
    db.refresh(notif)
    return notif

@router.delete("/{notif_id}")
def delete_notification(notif_id: int, db: Session = Depends(get_db)):
    notif = db.query(Notification).filter(Notification.notif_id == notif_id).first()
    if not notif:
        raise HTTPException(status_code=404, detail="Notification not found")
    db.delete(notif)
    db.commit()
    return {"detail": "Notification deleted successfully"}
