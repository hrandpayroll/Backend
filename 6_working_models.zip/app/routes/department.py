from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.deps import get_db
from app.models.department import Department
from app.schemas.department import DepartmentCreate, DepartmentRead


router = APIRouter(
    prefix="/departments",
    tags=["Departments"]
)


@router.post("/departments/", response_model=DepartmentRead)
def create_department(dept: DepartmentCreate, db: Session = Depends(get_db)):
    db_dept = Department(**dept.dict())
    db.add(db_dept)
    db.commit()
    db.refresh(db_dept)
    return db_dept

@router.get("/departments/{dept_id}", response_model=DepartmentRead)
def read_department(dept_id: int, db: Session = Depends(get_db)):
    dept = db.query(Department).filter(Department.department_id == dept_id).first()
    if not dept:
        raise HTTPException(status_code=404, detail="Department not found")
    return dept

@router.get("/", response_model=list[DepartmentRead])
def get_all_departments(db: Session = Depends(get_db)):
    return db.query(Department).all()

@router.patch("/{dept_id}", response_model=DepartmentRead)
def update_department(dept_id: int, updated: DepartmentCreate, db: Session = Depends(get_db)):
    dept = db.query(Department).filter(Department.department_id == dept_id).first()
    if not dept:
        raise HTTPException(status_code=404, detail="Department not found")
    for key, value in updated.dict().items():
        setattr(dept, key, value)
    db.commit()
    db.refresh(dept)
    return dept

@router.delete("/{dept_id}")
def delete_department(dept_id: int, db: Session = Depends(get_db)):
    dept = db.query(Department).filter(Department.department_id == dept_id).first()
    if not dept:
        raise HTTPException(status_code=404, detail="Department not found")
    db.delete(dept)
    db.commit()
    return {"detail": "Department deleted successfully"}

