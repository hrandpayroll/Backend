from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.deps import get_db
from app.models.job_role import JobRole
from app.schemas.job_role import JobRoleCreate, JobRoleRead

router = APIRouter(
    prefix="/job_roles",
    tags=["Job Roles"]
)


@router.post("/job_roles/", response_model=JobRoleRead)
def create_job_role(role: JobRoleCreate, db: Session = Depends(get_db)):
    db_role = JobRole(**role.dict())
    db.add(db_role)
    db.commit()
    db.refresh(db_role)
    return db_role

@router.get("/job_roles/{role_id}", response_model=JobRoleRead)
def read_job_role(role_id: int, db: Session = Depends(get_db)):
    role = db.query(JobRole).filter(JobRole.job_role_id == role_id).first()
    if not role:
        raise HTTPException(status_code=404, detail="Job Role not found")
    return role

@router.get("/", response_model=list[JobRoleRead])
def get_all_job_roles(db: Session = Depends(get_db)):
    return db.query(JobRole).all()

@router.patch("/{role_id}", response_model=JobRoleRead)
def update_job_role(role_id: int, updated: JobRoleCreate, db: Session = Depends(get_db)):
    role = db.query(JobRole).filter(JobRole.job_role_id == role_id).first()
    if not role:
        raise HTTPException(status_code=404, detail="Job role not found")
    for key, value in updated.dict().items():
        setattr(role, key, value)
    db.commit()
    db.refresh(role)
    return role

@router.delete("/{role_id}")
def delete_job_role(role_id: int, db: Session = Depends(get_db)):
    role = db.query(JobRole).filter(JobRole.job_role_id == role_id).first()
    if not role:
        raise HTTPException(status_code=404, detail="Job role not found")
    db.delete(role)
    db.commit()
    return {"detail": "Job role deleted successfully"}
