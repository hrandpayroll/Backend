from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models.ai_retention_risk import AIRetentionRisk
from app.schemas.ai_retention_risk import AIRetentionRiskCreate, AIRetentionRiskRead, AIRetentionRiskUpdate
from app.deps import get_db

router = APIRouter(
    prefix="/ai_retention_risk",
    tags=["AI Retention Risk"]
)

@router.post("/", response_model=AIRetentionRiskRead)
def create_risk(data: AIRetentionRiskCreate, db: Session = Depends(get_db)):
    risk = AIRetentionRisk(**data.dict())
    db.add(risk)
    db.commit()
    db.refresh(risk)
    return risk

@router.get("/{risk_id}", response_model=AIRetentionRiskRead)
def get_risk(risk_id: int, db: Session = Depends(get_db)):
    risk = db.query(AIRetentionRisk).filter(AIRetentionRisk.id == risk_id).first()
    if not risk:
        raise HTTPException(status_code=404, detail="Risk score not found")
    return risk

@router.get("/", response_model=list[AIRetentionRiskRead])
def get_all_risks(db: Session = Depends(get_db)):
    return db.query(AIRetentionRisk).all()

@router.patch("/{risk_id}", response_model=AIRetentionRiskRead)
def update_risk(risk_id: int, update: AIRetentionRiskUpdate, db: Session = Depends(get_db)):
    risk = db.query(AIRetentionRisk).filter(AIRetentionRisk.id == risk_id).first()
    if not risk:
        raise HTTPException(status_code=404, detail="Risk score not found")
    for key, value in update.dict(exclude_unset=True).items():
        setattr(risk, key, value)
    db.commit()
    db.refresh(risk)
    return risk

@router.delete("/{risk_id}")
def delete_risk(risk_id: int, db: Session = Depends(get_db)):
    risk = db.query(AIRetentionRisk).filter(AIRetentionRisk.id == risk_id).first()
    if not risk:
        raise HTTPException(status_code=404, detail="Risk score not found")
    db.delete(risk)
    db.commit()
    return {"detail": "Retention risk entry deleted"}
