from sqlalchemy import Column, Integer, ForeignKey, Date, Text, Boolean
from sqlalchemy.orm import relationship
from app.database import Base

class PerformanceReview(Base):
    __tablename__ = "performance_reviews"

    review_id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"))
    reviewer_id = Column(Integer, ForeignKey("employees.employee_id"))
    review_period = Column(Date)
    rating = Column(Integer)
    strengths = Column(Text)
    areas_of_improvement = Column(Text)
    promotion_recommendation = Column(Boolean)

    employee = relationship("Employee", back_populates="performance_reviews", foreign_keys=[employee_id])
    reviewer = relationship("Employee", back_populates="reviews_given", foreign_keys=[reviewer_id])
