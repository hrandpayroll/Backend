from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from app.database import Base

class JobRole(Base):
    __tablename__ = "job_roles"

    job_role_id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    level = Column(String(255), nullable=False)

    # Relationship to Employee
    employees = relationship("Employee", back_populates="job_role")
