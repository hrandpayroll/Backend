from sqlalchemy import Column, Integer, ForeignKey, Float, DateTime
from sqlalchemy.orm import relationship
from app.database import Base
from datetime import datetime

class AIRetentionRisk(Base):
    __tablename__ = "ai_retention_risk"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"))
    risk_score = Column(Float)
    evaluated_on = Column(DateTime, default=datetime.utcnow)

    employee = relationship("Employee", back_populates="retention_risk")
