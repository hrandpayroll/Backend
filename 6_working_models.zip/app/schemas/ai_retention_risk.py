from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class AIRetentionRiskBase(BaseModel):
    employee_id: int
    risk_score: float

class AIRetentionRiskCreate(AIRetentionRiskBase):
    pass

class AIRetentionRiskUpdate(BaseModel):
    employee_id: Optional[int] = None
    risk_score: Optional[float] = None

class AIRetentionRiskRead(AIRetentionRiskBase):
    id: int
    evaluated_on: datetime

    class Config:
        orm_mode = True
