from pydantic import BaseModel

class JobRoleBase(BaseModel):
    title: str
    level: str

class JobRoleCreate(JobRoleBase):
    pass

class JobRoleRead(JobRoleBase):
    job_role_id: int

    class Config:
        orm_mode = True
