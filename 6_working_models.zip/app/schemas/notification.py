from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class NotificationBase(BaseModel):
    employee_id: int
    message: str
    is_read: Optional[bool] = False

class NotificationCreate(NotificationBase):
    pass

class NotificationUpdate(BaseModel):
    employee_id: Optional[int] = None
    message: Optional[str] = None
    is_read: Optional[bool] = None

class NotificationRead(NotificationBase):
    notif_id: int
    created_at: datetime

    class Config:
        orm_mode = True
