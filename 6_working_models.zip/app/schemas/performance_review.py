from pydantic import BaseModel
from datetime import date
from typing import Optional

class PerformanceReviewBase(BaseModel):
    employee_id: int
    reviewer_id: int
    review_period: date
    rating: int
    strengths: Optional[str] = None
    areas_of_improvement: Optional[str] = None
    promotion_recommendation: bool

class PerformanceReviewCreate(PerformanceReviewBase):
    pass

class PerformanceReviewRead(PerformanceReviewBase):
    review_id: int

    class Config:
        orm_mode = True

class PerformanceReviewUpdate(BaseModel):
    employee_id: Optional[int] = None
    reviewer_id: Optional[int] = None
    review_period: Optional[date] = None
    rating: Optional[int] = None
    strengths: Optional[str] = None
    areas_of_improvement: Optional[str] = None
    promotion_recommendation: Optional[bool] = None
